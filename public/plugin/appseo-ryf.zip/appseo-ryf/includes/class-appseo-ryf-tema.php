<?php
/**
 * Huella del tema activo.
 *
 * El objetivo es que el panel no tenga que estudiar cada cliente a mano. El
 * marcado de WooCommerce es idéntico en todos los temas — lo que cambia es el
 * envoltorio: la cabecera de página, el contenedor de contenido, las variables
 * de color. Este módulo detecta justo esa parte variable y la devuelve, para que
 * una hoja de estilos base escrita contra clases estándar se adapte con un
 * puñado de reglas en vez de reescribirse entera.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reconocimiento del tema.
 */
class AppSEO_RyF_Tema {

	/**
	 * Contenedores de cabecera de página conocidos, por familia de tema.
	 *
	 * Se comprueban contra el HTML real del sitio: se informa solo de los que
	 * existen de verdad, no de los que podrían existir.
	 *
	 * @return array
	 */
	public static function candidatos_cabecera() {
		return apply_filters(
			'appseo_ryf_candidatos_cabecera',
			array(
				'page-hero'                => 'GeneratePress (GP Premium)',
				'generate-page-header'     => 'GeneratePress',
				'ast-container--narrow'    => 'Astra',
				'entry-banner'             => 'Astra',
				'page-header'              => 'genérico',
				'entry-header'             => 'genérico',
				'ct-container'             => 'Blocksy',
				'page-hero-section'        => 'Blocksy',
				'entry-hero'               => 'Kadence',
				'page-title'               => 'OceanWP / genérico',
				'et_pb_title_container'    => 'Divi',
				'page-header-inner'        => 'Flatsome',
				'woocommerce-products-header' => 'Storefront / WooCommerce',
			)
		);
	}

	/**
	 * Devuelve la huella completa del tema.
	 *
	 * @return array
	 */
	public function huella( $url = '' ) {
		$tema = wp_get_theme();

		return array(
			'tema'         => array(
				'nombre'   => $tema->get( 'Name' ),
				'version'  => $tema->get( 'Version' ),
				'slug'     => get_stylesheet(),
				'padre'    => $tema->parent() ? $tema->parent()->get( 'Name' ) : '',
				'es_bloques' => function_exists( 'wp_is_block_theme' ) ? wp_is_block_theme() : false,
			),
			'plantillas'   => AppSEO_RyF_Content::plantillas_disponibles(),
			'variables'    => $this->variables_css(),
			'woocommerce'  => $this->info_woocommerce(),
			'envoltorio'   => $this->detectar_envoltorio( $url ),
		);
	}

	/**
	 * Variables CSS que declara el tema.
	 *
	 * Un tema moderno declara su paleta con propiedades personalizadas. Si el
	 * panel las conoce, puede escribir CSS que use los colores del cliente en
	 * lugar de imponer los suyos.
	 *
	 * @return array
	 */
	protected function variables_css() {
		$salida = array( 'theme_json' => array(), 'stylesheet' => array() );

		// theme.json: la fuente ordenada, cuando existe.
		if ( class_exists( 'WP_Theme_JSON_Resolver' ) ) {
			$datos = WP_Theme_JSON_Resolver::get_merged_data()->get_settings();
			if ( ! empty( $datos['color']['palette'] ) ) {
				foreach ( (array) $datos['color']['palette'] as $origen => $colores ) {
					foreach ( (array) $colores as $color ) {
						if ( isset( $color['slug'], $color['color'] ) ) {
							$salida['theme_json'][ $color['slug'] ] = $color['color'];
						}
					}
				}
			}
		}

		// Y las que el tema declara a pelo en su hoja de estilos.
		$ruta = get_stylesheet_directory() . '/style.css';
		if ( is_readable( $ruta ) && filesize( $ruta ) < 900000 ) {
			$css = file_get_contents( $ruta ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( preg_match_all( '/(--[a-z0-9-]+)\s*:\s*(#[0-9a-f]{3,8}|rgba?\([^)]+\))/i', (string) $css, $m, PREG_SET_ORDER ) ) {
				foreach ( array_slice( $m, 0, 60 ) as $par ) {
					$salida['stylesheet'][ $par[1] ] = $par[2];
				}
			}
		}

		return $salida;
	}

	/**
	 * Estado de WooCommerce y si el tema pisa sus plantillas.
	 *
	 * Un tema que sobrescribe las plantillas de WooCommerce puede cambiar el
	 * marcado, y ahí es donde una hoja base deja de aplicar.
	 *
	 * @return array
	 */
	protected function info_woocommerce() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array( 'activo' => false );
		}

		$sobrescritas = array();
		foreach ( array( get_stylesheet_directory(), get_template_directory() ) as $base ) {
			$dir = $base . '/woocommerce';
			if ( ! is_dir( $dir ) ) {
				continue;
			}
			$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );
			foreach ( $it as $archivo ) {
				if ( 'php' === strtolower( $archivo->getExtension() ) ) {
					$sobrescritas[] = str_replace( $dir . DIRECTORY_SEPARATOR, '', $archivo->getPathname() );
				}
				if ( count( $sobrescritas ) > 80 ) {
					break 2;
				}
			}
		}

		return array(
			'activo'        => true,
			'version'       => defined( 'WC_VERSION' ) ? WC_VERSION : '',
			'sobrescritas'  => array_values( array_unique( $sobrescritas ) ),
			'total_sobrescritas' => count( $sobrescritas ),
		);
	}

	/**
	 * Elige qué URL analizar.
	 *
	 * La portada es la peor candidata posible: casi siempre lleva maquetación
	 * propia y no muestra la cabecera de página que sí aparece en el resto del
	 * sitio. Se busca, en este orden, un producto publicado, una página que no
	 * sea la portada, una entrada, y solo como último recurso la portada.
	 *
	 * @param string $pedida URL concreta impuesta por el panel.
	 * @return string
	 */
	protected function url_representativa( $pedida = '' ) {
		if ( $pedida && wp_http_validate_url( $pedida ) ) {
			return $pedida;
		}

		if ( function_exists( 'wc_get_products' ) ) {
			$productos = wc_get_products( array( 'limit' => 1, 'status' => 'publish' ) );
			if ( ! empty( $productos ) ) {
				return get_permalink( $productos[0]->get_id() );
			}
		}

		$portada = (int) get_option( 'page_on_front' );
		$paginas = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'numberposts' => 3,
				'exclude'     => array_filter( array( $portada, (int) get_option( 'page_for_posts' ) ) ),
			)
		);
		if ( ! empty( $paginas ) ) {
			return get_permalink( $paginas[0]->ID );
		}

		$entradas = get_posts( array( 'post_status' => 'publish', 'numberposts' => 1 ) );
		if ( ! empty( $entradas ) ) {
			return get_permalink( $entradas[0]->ID );
		}

		return home_url( '/' );
	}

	/**
	 * Detecta qué contenedores de cabecera existen realmente.
	 *
	 * En lugar de suponer por el nombre del tema, se descarga una página del
	 * propio sitio y se comprueba cuáles de las clases conocidas aparecen. Así
	 * funciona igual con un tema a medida que con uno comercial.
	 *
	 * @return array
	 */
	protected function detectar_envoltorio( $url_pedida = '' ) {
		$url = $this->url_representativa( $url_pedida );

		$respuesta = wp_remote_get(
			add_query_arg( 'appseo_sonda', time(), $url ),
			array( 'timeout' => 12, 'sslverify' => false )
		);

		if ( is_wp_error( $respuesta ) ) {
			return array(
				'url_analizada' => $url,
				'error'         => $respuesta->get_error_message(),
				'encontrados'   => array(),
			);
		}

		$html = wp_remote_retrieve_body( $respuesta );
		$encontrados = array();

		foreach ( self::candidatos_cabecera() as $clase => $familia ) {
			if ( false !== strpos( $html, 'class="' . $clase ) || false !== strpos( $html, ' ' . $clase . ' ' ) || false !== strpos( $html, ' ' . $clase . '"' ) ) {
				$encontrados[] = array( 'clase' => $clase, 'familia' => $familia );
			}
		}

		$cortina = $this->detectar_cortina( $html );

		return array(
			'url_analizada'  => $url,
			'cortina'        => $cortina,
			'codigo'        => wp_remote_retrieve_response_code( $respuesta ),
			'bytes'         => strlen( $html ),
			'encontrados'   => $encontrados,
			'migas_woo'     => ( false !== strpos( $html, 'woocommerce-breadcrumb' ) ),
			'marcado_woo'   => $this->marcado_woo( $html ),
		);
	}
	/**
	 * Detecta si lo servido es una cortina en vez de la página real.
	 *
	 * Un sitio en modo «próximamente» o en mantenimiento devuelve 200 y un HTML
	 * completo, así que ni el código ni el tamaño delatan nada. Lo único fiable
	 * es el marcado que imprime quien pone la cortina: WooCommerce marca la suya
	 * con una clase propia. Sin esto, el panel escribiría CSS contra selectores
	 * que nunca existen y daría el trabajo por hecho.
	 *
	 * @param string $html HTML servido.
	 * @return array
	 */
	protected function detectar_cortina( $html ) {
		$señales = array(
			'woocommerce-coming-soon' => 'WooCommerce · modo próximamente',
			'wp-block-woocommerce-coming-soon' => 'WooCommerce · bloque de próximamente',
			'seed-csp4'               => 'plugin de próximamente',
			'maintenance-mode'        => 'modo mantenimiento',
		);

		$encontradas = array();
		foreach ( $señales as $marca => $motivo ) {
			if ( false !== strpos( $html, $marca ) ) {
				$encontradas[] = $motivo;
			}
		}

		return array(
			'activa'  => ! empty( $encontradas ),
			'motivos' => array_values( array_unique( $encontradas ) ),
		);
	}

	/**
	 * Comprueba que el marcado estándar de WooCommerce llegó a la página.
	 *
	 * Una hoja de estilos base se escribe contra estas clases. Si no están —
	 * porque hay una cortina delante, o porque el tema sustituye la plantilla
	 * por bloques con clases generadas — esa hoja no aplicará a nada, y es mejor
	 * decirlo que aplicarla y dar el trabajo por bueno.
	 *
	 * @param string $html HTML servido.
	 * @return array
	 */
	protected function marcado_woo( $html ) {
		// Solo el marcado, no el CSS ni el JS en línea: ahí estas cadenas
		// aparecen aunque la plantilla no se haya renderizado.
		$solo_marcado = preg_replace( '#<(style|script)\b[^>]*>.*?</\1>#is', '', $html );

		$clases = array(
			'woocommerce-product-gallery',
			'summary',
			'product_title',
			'single_add_to_cart_button',
			'woocommerce-tabs',
			'woocommerce-breadcrumb',
		);

		$presentes = array();
		$ausentes  = array();
		foreach ( $clases as $clase ) {
			if ( preg_match( '/class="[^"]*\b' . preg_quote( $clase, '/' ) . '\b/', (string) $solo_marcado ) ) {
				$presentes[] = $clase;
			} else {
				$ausentes[] = $clase;
			}
		}

		return array(
			'presentes' => $presentes,
			'ausentes'  => $ausentes,
			'estandar'  => count( $presentes ) >= 4,
		);
	}
}
