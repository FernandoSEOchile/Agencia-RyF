<?php
/**
 * Registro de actividad del conector.
 *
 * Cada operación de escritura deja constancia: qué se hizo, sobre qué, cuándo y
 * con qué resultado. No es decoración — es lo que le enseñas a un cliente que
 * pregunta «¿quién tocó mi web el martes?».
 *
 * Vive en su propia tabla en lugar de en una opción, porque una opción con
 * miles de entradas se carga entera en cada petición de WordPress.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Escritura y consulta del registro.
 */
class AppSEO_RyF_Log {

	/** Versión del esquema, para saber cuándo hay que recrear la tabla. */
	const ESQUEMA = 1;

	/** Opción donde se guarda la versión del esquema instalada. */
	const OPCION_ESQUEMA = 'appseo_ryf_log_esquema';

	/** Opción donde se guarda el motivo del último fallo de anotación. */
	const OPCION_FALLO = 'appseo_ryf_log_fallo';

	/** Entradas que se conservan antes de podar las más antiguas. */
	const MAXIMO = 2000;

	/**
	 * Nombre completo de la tabla.
	 *
	 * @return string
	 */
	public static function tabla() {
		global $wpdb;
		return $wpdb->prefix . 'appseo_ryf_log';
	}

	/** Bandera en memoria, para no repetir la comprobación en cada anotación. */
	protected static $comprobada = false;

	/**
	 * ¿Existe realmente la tabla?
	 *
	 * @return bool
	 */
	public static function tabla_existe() {
		global $wpdb;
		$tabla = self::tabla();
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tabla ) );
	}

	/**
	 * Crea la tabla si hace falta y confirma que quedó creada.
	 *
	 * La versión anterior daba el esquema por instalado en cuanto llamaba a
	 * dbDelta, sin comprobar nada. Si dbDelta fallaba, la opción quedaba puesta,
	 * no se reintentaba nunca más y las anotaciones se perdían en silencio.
	 *
	 * @param bool $forzar Recrear aunque la opción diga que ya está.
	 * @return bool Si la tabla está disponible.
	 */
	public static function instalar( $forzar = false ) {
		if ( ! $forzar && self::$comprobada ) {
			return true;
		}

		if ( ! $forzar
			&& (int) get_option( self::OPCION_ESQUEMA, 0 ) === self::ESQUEMA
			&& self::tabla_existe() ) {
			self::$comprobada = true;
			return true;
		}

		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tabla   = self::tabla();
		$collate = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$tabla} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				creado datetime NOT NULL,
				accion varchar(40) NOT NULL,
				objeto_tipo varchar(24) NOT NULL DEFAULT '',
				objeto_id bigint(20) unsigned NOT NULL DEFAULT 0,
				resumen text NOT NULL,
				resultado varchar(12) NOT NULL DEFAULT 'ok',
				usuario_id bigint(20) unsigned NOT NULL DEFAULT 0,
				ip varchar(45) NOT NULL DEFAULT '',
				PRIMARY KEY  (id),
				KEY creado (creado),
				KEY accion (accion)
			) {$collate};"
		);

		$creada = self::tabla_existe();

		if ( $creada ) {
			update_option( self::OPCION_ESQUEMA, self::ESQUEMA, false );
			self::$comprobada = true;
		} else {
			// Sin tabla no se marca nada: así el siguiente intento vuelve a probar
			// en lugar de dar por bueno un esquema que no existe.
			delete_option( self::OPCION_ESQUEMA );
		}

		return $creada;
	}

	/**
	 * Estado del registro, para diagnosticar desde el panel.
	 *
	 * @return array
	 */
	public static function diagnostico() {
		global $wpdb;

		$existe = self::tabla_existe();

		return array(
			'tabla'          => self::tabla(),
			'existe'         => $existe,
			'esquema_opcion' => (int) get_option( self::OPCION_ESQUEMA, 0 ),
			'esquema_actual' => self::ESQUEMA,
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'filas'          => $existe ? (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::tabla() ) : 0,
			'ultimo_error'   => $wpdb->last_error ? $wpdb->last_error : '',
			'ultimo_fallo'   => get_option( self::OPCION_FALLO, null ),
			'columnas'       => $existe ? $wpdb->get_col( 'DESCRIBE ' . self::tabla(), 0 ) : array(),
		);
	}

	/**
	 * Inserta una fila de prueba y devuelve exactamente qué ocurrió.
	 *
	 * Distingue «la tabla no existe» de «la tabla existe pero el insert falla»,
	 * que son problemas muy distintos y hasta ahora se confundían porque los dos
	 * terminaban en silencio.
	 *
	 * @return array
	 */
	public static function probar() {
		global $wpdb;

		if ( ! self::instalar() ) {
			return array( 'ok' => false, 'fase' => 'instalar', 'error' => 'no se pudo crear la tabla' );
		}

		$antes = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::tabla() );

		$r = $wpdb->insert(
			self::tabla(),
			array(
				'creado'      => current_time( 'mysql' ),
				'accion'      => 'prueba_registro',
				'objeto_tipo' => 'diagnostico',
				'objeto_id'   => 0,
				'resumen'     => 'Inserción de prueba lanzada desde el panel',
				'resultado'   => 'ok',
				'usuario_id'  => 0,
				'ip'          => '',
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s' )
		);

		$despues = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::tabla() );

		return array(
			'ok'            => ( false !== $r ),
			'fase'          => 'insert',
			'devuelto'      => $r,
			'filas_antes'   => $antes,
			'filas_despues' => $despues,
			'error'         => $wpdb->last_error ? $wpdb->last_error : '',
			'consulta'      => $wpdb->last_query,
		);
	}

	/**
	 * Anota una operación.
	 *
	 * @param string $accion    Identificador corto, por ejemplo `contenido.crear`.
	 * @param array  $datos {
	 *     @type string $resumen   Descripción legible.
	 *     @type string $tipo      Tipo de objeto afectado.
	 *     @type int    $id        Identificador del objeto.
	 *     @type string $resultado `ok` o `error`.
	 * }
	 * @return void
	 */
	public static function anotar( $accion, array $datos = array() ) {
		global $wpdb;

		if ( ! self::instalar() ) {
			self::recordar_fallo( 'la tabla no está disponible' );
			return;
		}

		// El valor se resuelve antes y en una variable propia. Escrito en una
		// sola expresión, el `?? 'ok'` solo afectaba a la comprobación y el
		// ternario devolvía el original — que era null cuando el llamante no
		// pasaba `resultado`, y MySQL rechazaba la fila entera.
		$resultado = $datos['resultado'] ?? 'ok';
		if ( ! in_array( $resultado, array( 'ok', 'error', 'bloqueado' ), true ) ) {
			$resultado = 'ok';
		}

		$insertadas = $wpdb->insert(
			self::tabla(),
			array(
				'creado'      => current_time( 'mysql' ),
				'accion'      => substr( sanitize_key( $accion ), 0, 40 ),
				'objeto_tipo' => substr( sanitize_key( $datos['tipo'] ?? '' ), 0, 24 ),
				'objeto_id'   => (int) ( $datos['id'] ?? 0 ),
				'resumen'     => wp_strip_all_tags( (string) ( $datos['resumen'] ?? '' ) ),
				'resultado'   => $resultado,
				'usuario_id'  => (int) AppSEO_RyF_Settings::acting_user_id(),
				'ip'          => AppSEO_RyF_Auth::client_ip(),
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s' )
		);

		// Un insert fallido devuelve false sin lanzar nada. Si no se guarda el
		// motivo aquí, el fallo desaparece sin dejar rastro: exactamente lo que
		// pasó con la primera versión de este registro.
		if ( false === $insertadas ) {
			self::recordar_fallo( $wpdb->last_error ? $wpdb->last_error : 'insert devolvió false sin error' );
			return;
		}

		delete_option( self::OPCION_FALLO );

		// Poda ocasional: no en cada inserción, para no pagar el coste siempre.
		if ( 0 === wp_rand( 0, 24 ) ) {
			self::podar();
		}
	}

	/**
	 * Guarda el motivo del último fallo de anotación.
	 *
	 * @param string $motivo Descripción.
	 * @return void
	 */
	protected static function recordar_fallo( $motivo ) {
		update_option(
			self::OPCION_FALLO,
			array(
				'cuando' => current_time( 'mysql' ),
				'motivo' => substr( (string) $motivo, 0, 500 ),
			),
			false
		);
	}

	/**
	 * Elimina las entradas más antiguas por encima del máximo.
	 *
	 * @return void
	 */
	public static function podar() {
		global $wpdb;
		$tabla = self::tabla();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$corte = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM {$tabla} ORDER BY id DESC LIMIT 1 OFFSET %d", self::MAXIMO )
		);
		if ( $corte ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$tabla} WHERE id <= %d", $corte ) );
		}
		// phpcs:enable
	}

	/**
	 * Devuelve entradas del registro.
	 *
	 * @param array $args {
	 *     @type int    $pagina    Página, empezando en 1.
	 *     @type int    $por_pagina Entradas por página.
	 *     @type string $resultado Filtro por resultado.
	 * }
	 * @return array
	 */
	public static function consultar( array $args = array() ) {
		global $wpdb;

		if ( ! self::instalar() ) {
			return array( 'entradas' => array(), 'total' => 0, 'paginas' => 0, 'pagina' => 1, 'conteo' => array( 'ok' => 0, 'error' => 0, 'bloqueado' => 0 ) );
		}

		$tabla      = self::tabla();
		$por_pagina = max( 1, min( 200, (int) ( $args['por_pagina'] ?? 40 ) ) );
		$pagina     = max( 1, (int) ( $args['pagina'] ?? 1 ) );
		$offset     = ( $pagina - 1 ) * $por_pagina;
		$filtro     = $args['resultado'] ?? '';

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( in_array( $filtro, array( 'ok', 'error', 'bloqueado' ), true ) ) {
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tabla} WHERE resultado = %s", $filtro ) );
			$filas = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$tabla} WHERE resultado = %s ORDER BY id DESC LIMIT %d OFFSET %d", $filtro, $por_pagina, $offset )
			);
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tabla}" );
			$filas = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$tabla} ORDER BY id DESC LIMIT %d OFFSET %d", $por_pagina, $offset )
			);
		}

		$resumen = $wpdb->get_results( "SELECT resultado, COUNT(*) AS total FROM {$tabla} GROUP BY resultado" );
		// phpcs:enable

		$conteo = array( 'ok' => 0, 'error' => 0, 'bloqueado' => 0 );
		foreach ( (array) $resumen as $fila ) {
			$conteo[ $fila->resultado ] = (int) $fila->total;
		}

		return array(
			'entradas' => (array) $filas,
			'total'    => $total,
			'paginas'  => (int) ceil( $total / $por_pagina ),
			'pagina'   => $pagina,
			'conteo'   => $conteo,
		);
	}

	/**
	 * Etiqueta legible para cada acción.
	 *
	 * @param string $accion Identificador.
	 * @return string
	 */
	public static function etiqueta( $accion ) {
		$mapa = array(
			'contenido_crear'    => __( 'Contenido creado', 'appseo-ryf' ),
			'contenido_editar'   => __( 'Contenido editado', 'appseo-ryf' ),
			'contenido_publicar' => __( 'Contenido publicado', 'appseo-ryf' ),
			'producto_crear'     => __( 'Producto creado', 'appseo-ryf' ),
			'producto_editar'    => __( 'Producto editado', 'appseo-ryf' ),
			'medio_subir'        => __( 'Imagen subida', 'appseo-ryf' ),
			'plugin_instalar'    => __( 'Plugin instalado', 'appseo-ryf' ),
			'plugin_activar'     => __( 'Plugin activado', 'appseo-ryf' ),
			'plugin_desactivar'  => __( 'Plugin desactivado', 'appseo-ryf' ),
			'ajustes_guardar'    => __( 'Permisos modificados', 'appseo-ryf' ),
			'credenciales_nuevas'=> __( 'Credenciales regeneradas', 'appseo-ryf' ),
			'auditoria'          => __( 'Auditoría solicitada', 'appseo-ryf' ),
		);

		return $mapa[ $accion ] ?? ucfirst( str_replace( '_', ' ', $accion ) );
	}
}
