<?php
/**
 * CSS adicional del sitio.
 *
 * WordPress guarda el «CSS adicional» del personalizador en un contenido de
 * tipo `custom_css`, no en un archivo. Se escribe con la función del núcleo, que
 * mantiene el historial de revisiones — así un cambio siempre se puede deshacer
 * desde el propio WordPress.
 *
 * Es la única parte del conector que puede alterar el aspecto de todo el sitio,
 * así que va con el mismo interruptor de escritura que el contenido y queda
 * registrada como cualquier otra operación.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Lectura y escritura del CSS adicional.
 */
class AppSEO_RyF_Estilos {

	/** Tope de tamaño, para no llenar la base de datos por accidente. */
	const MAXIMO_BYTES = 200000;

	/**
	 * Devuelve el CSS adicional actual.
	 *
	 * @return array
	 */
	public function obtener() {
		$css = wp_get_custom_css();

		return array(
			'tema'      => get_stylesheet(),
			'css'       => is_string( $css ) ? $css : '',
			'bytes'     => strlen( (string) $css ),
			'revisiones' => $this->contar_revisiones(),
		);
	}

	/**
	 * Cuántas revisiones guarda WordPress del CSS.
	 *
	 * @return int
	 */
	protected function contar_revisiones() {
		$post = wp_get_custom_css_post();
		return $post ? count( wp_get_post_revisions( $post->ID ) ) : 0;
	}

	/**
	 * Escribe el CSS adicional.
	 *
	 * @param string $css  Hoja de estilos.
	 * @param string $modo `reemplazar` o `anexar`.
	 * @return array|WP_Error
	 */
	public function guardar( $css, $modo = 'reemplazar' ) {
		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return new WP_Error(
				'appseo_read_only',
				__( 'Este sitio está en modo solo lectura.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$css = (string) $css;

		if ( strlen( $css ) > self::MAXIMO_BYTES ) {
			return new WP_Error(
				'appseo_css_grande',
				sprintf(
					/* translators: %s: tamaño máximo en kilobytes. */
					__( 'El CSS supera el máximo de %s KB.', 'appseo-ryf' ),
					number_format_i18n( self::MAXIMO_BYTES / 1024 )
				),
				array( 'status' => 413 )
			);
		}

		$css = $this->sanear( $css );

		$anterior = wp_get_custom_css();
		$anterior = is_string( $anterior ) ? $anterior : '';

		if ( 'anexar' === $modo ) {
			$css = rtrim( $anterior ) . "\n\n" . $css;
		}

		$resultado = wp_update_custom_css_post( $css );

		if ( is_wp_error( $resultado ) ) {
			AppSEO_RyF_Log::anotar(
				'css_guardar',
				array( 'resultado' => 'error', 'resumen' => $resultado->get_error_message() )
			);
			return $resultado;
		}

		AppSEO_RyF_Log::anotar(
			'css_guardar',
			array(
				'tipo'    => 'custom_css',
				'id'      => $resultado->ID,
				'resumen' => sprintf(
					/* translators: 1: modo, 2: bytes antes, 3: bytes después. */
					__( '%1$s · de %2$s a %3$s bytes', 'appseo-ryf' ),
					'anexar' === $modo ? __( 'anexado', 'appseo-ryf' ) : __( 'reemplazado', 'appseo-ryf' ),
					number_format_i18n( strlen( $anterior ) ),
					number_format_i18n( strlen( $css ) )
				),
			)
		);

		return array(
			'ok'         => true,
			'modo'       => $modo,
			'bytes'      => strlen( $css ),
			'anterior'   => $anterior,
			'post_id'    => $resultado->ID,
			'revisiones' => $this->contar_revisiones(),
		);
	}

	/**
	 * Limpia lo que no debe viajar dentro de una hoja de estilos.
	 *
	 * El CSS no ejecuta código por sí mismo, pero una cadena que cierre la
	 * etiqueta `<style>` sí permitiría inyectar marcado en la página.
	 *
	 * @param string $css Hoja de estilos.
	 * @return string
	 */
	protected function sanear( $css ) {
		$css = preg_replace( '#</\s*style#i', '', $css );
		$css = preg_replace( '#<\s*script#i', '', $css );
		$css = preg_replace( '#javascript\s*:#i', '', $css );
		// `expression()` solo lo entendían navegadores muy antiguos, pero ahí
		// sí ejecutaba JavaScript desde una hoja de estilos.
		$css = preg_replace( '#expression\s*\(#i', '(', $css );

		return trim( $css );
	}
}
