<?php
/**
 * Lectura y escritura de contenido.
 *
 * Escribe metadatos protegidos (Yoast, Elementor) que la REST API del núcleo no
 * expone, pero solo los de una lista blanca explícita. No hay escritura de meta
 * arbitrario: sería una puerta trasera disfrazada.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Operaciones sobre entradas y páginas.
 */
class AppSEO_RyF_Content {

	/**
	 * Prefijos de metadatos que se permite escribir.
	 *
	 * @return array
	 */
	public static function allowed_meta_prefixes() {
		return apply_filters(
			'appseo_ryf_allowed_meta_prefixes',
			array(
				'_yoast_wpseo_',
				'_elementor_',
				'rank_math_',
			)
		);
	}

	/**
	 * Tipos MIME aceptados al subir archivos.
	 *
	 * SVG queda fuera a propósito: puede contener JavaScript y convertirse en un
	 * vector de XSS en el sitio del cliente. Se habilita con un filtro si
	 * alguien acepta ese riesgo conscientemente.
	 *
	 * @return array
	 */
	public static function allowed_mimes() {
		return apply_filters(
			'appseo_ryf_allowed_mimes',
			array(
				'jpg|jpeg|jpe' => 'image/jpeg',
				'png'          => 'image/png',
				'gif'          => 'image/gif',
				'webp'         => 'image/webp',
				'avif'         => 'image/avif',
				'pdf'          => 'application/pdf',
			)
		);
	}

	/**
	 * Devuelve una pieza completa.
	 *
	 * @param int $post_id ID.
	 * @return array|WP_Error
	 */
	public function get( $post_id ) {
		$post = get_post( (int) $post_id );

		if ( ! $post || ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) {
			return new WP_Error(
				'appseo_not_found',
				__( 'No existe una entrada o página con ese identificador.', 'appseo-ryf' ),
				array( 'status' => 404 )
			);
		}

		$meta = array();
		foreach ( self::allowed_meta_prefixes() as $prefijo ) {
			foreach ( get_post_meta( $post->ID ) as $clave => $valores ) {
				if ( 0 === strpos( $clave, $prefijo ) ) {
					$meta[ $clave ] = maybe_unserialize( $valores[0] );
				}
			}
		}

		return array(
			'id'         => $post->ID,
			'titulo'     => $post->post_title,
			'slug'       => $post->post_name,
			'url'        => get_permalink( $post->ID ),
			'tipo'       => $post->post_type,
			'estado'     => $post->post_status,
			'parent'     => (int) $post->post_parent,
			'contenido'  => $post->post_content,
			'extracto'   => $post->post_excerpt,
			'destacada'  => get_post_thumbnail_id( $post->ID ) ?: 0,
			'plantilla'  => get_page_template_slug( $post->ID ),
			'categorias' => wp_get_post_categories( $post->ID ),
			'etiquetas'  => wp_get_post_tags( $post->ID, array( 'fields' => 'ids' ) ),
			'meta'       => $meta,
			'modificado' => $post->post_modified_gmt,
		);
	}

	/**
	 * Crea o actualiza una pieza.
	 *
	 * @param array $data Datos entrantes ya validados por el esquema REST.
	 * @return array|WP_Error
	 */
	public function upsert( array $data ) {
		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return new WP_Error(
				'appseo_read_only',
				__( 'Este sitio está en modo solo lectura. Actívalo en los ajustes de AppSEO RyF para permitir cambios.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$autor = AppSEO_RyF_Settings::acting_user_id();
		if ( ! $autor ) {
			return new WP_Error(
				'appseo_no_acting_user',
				__( 'No hay un usuario válido configurado para atribuir los cambios.', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}

		$id      = isset( $data['id'] ) ? (int) $data['id'] : 0;
		$estado  = isset( $data['estado'] ) ? sanitize_key( $data['estado'] ) : 'draft';
		$estados = array( 'draft', 'pending', 'private', 'publish' );

		if ( ! in_array( $estado, $estados, true ) ) {
			$estado = 'draft';
		}

		if ( 'publish' === $estado && ! AppSEO_RyF_Settings::get( 'allow_publish', 0 ) ) {
			return new WP_Error(
				'appseo_publish_disabled',
				__( 'La publicación directa está desactivada en este sitio. El contenido puede crearse como borrador.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		// Estado previo, para que el panel pueda deshacer.
		$anterior = $id ? $this->get( $id ) : null;
		if ( is_wp_error( $anterior ) ) {
			return $anterior;
		}

		$postarr = array(
			'post_type'   => isset( $data['tipo'] ) && 'page' === $data['tipo'] ? 'page' : 'post',
			'post_status' => $estado,
			'post_author' => $autor,
		);

		if ( $id ) {
			$postarr['ID'] = $id;
			unset( $postarr['post_type'] );
		}

		if ( isset( $data['titulo'] ) ) {
			$postarr['post_title'] = sanitize_text_field( $data['titulo'] );
		}
		if ( isset( $data['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $data['slug'] );
		}
		if ( isset( $data['contenido'] ) ) {
			$postarr['post_content'] = $this->sanitize_content( $data['contenido'] );
		}
		if ( isset( $data['extracto'] ) ) {
			$postarr['post_excerpt'] = sanitize_textarea_field( $data['extracto'] );
		}
		if ( isset( $data['parent'] ) ) {
			$postarr['post_parent'] = (int) $data['parent'];
		}
		if ( isset( $data['plantilla'] ) ) {
			$postarr['page_template'] = self::validar_plantilla( $data['plantilla'] );
		}

		$resultado = $id ? wp_update_post( $postarr, true ) : wp_insert_post( $postarr, true );

		if ( is_wp_error( $resultado ) ) {
			return $resultado;
		}

		$post_id = (int) $resultado;

		if ( isset( $data['categorias'] ) && is_array( $data['categorias'] ) ) {
			wp_set_post_categories( $post_id, array_map( 'intval', $data['categorias'] ) );
		}
		if ( isset( $data['etiquetas'] ) && is_array( $data['etiquetas'] ) ) {
			wp_set_post_tags( $post_id, array_map( 'sanitize_text_field', $data['etiquetas'] ) );
		}
		if ( isset( $data['destacada'] ) ) {
			$thumb = (int) $data['destacada'];
			if ( $thumb > 0 ) {
				set_post_thumbnail( $post_id, $thumb );
			} else {
				delete_post_thumbnail( $post_id );
			}
		}

		$meta_escrito = array();
		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			$meta_escrito = $this->write_meta( $post_id, $data['meta'] );
		}

		AppSEO_RyF_Log::anotar(
			$id ? ( 'publish' === $estado ? 'contenido_publicar' : 'contenido_editar' ) : 'contenido_crear',
			array(
				'tipo'    => get_post_type( $post_id ),
				'id'      => $post_id,
				'resumen' => sprintf(
					/* translators: 1: título, 2: estado. */
					__( '«%1$s» (%2$s)', 'appseo-ryf' ),
					get_the_title( $post_id ),
					get_post_status( $post_id )
				),
			)
		);

		return array(
			'id'           => $post_id,
			'creado'       => ! $id,
			'url'          => get_permalink( $post_id ),
			// `get_edit_post_link()` devuelve null sin un usuario en sesión, y
			// en una petición REST firmada no lo hay. Se construye a mano.
			'editar'       => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
			'estado'       => get_post_status( $post_id ),
			'meta_escrito' => $meta_escrito,
			'anterior'     => $anterior,
		);
	}

	/**
	 * Plantillas de página disponibles en este sitio.
	 *
	 * Incluye las del tema activo y las que añade Elementor, que son las que
	 * quitan la cabecera del tema en una landing.
	 *
	 * @return array Mapa archivo => nombre legible.
	 */
	public static function plantillas_disponibles() {
		$plantillas = array( 'default' => __( 'Predeterminada del tema', 'appseo-ryf' ) );

		$tema = wp_get_theme();
		foreach ( $tema->get_page_templates( null, 'page' ) as $archivo => $nombre ) {
			$plantillas[ $archivo ] = $nombre;
		}

		return $plantillas;
	}

	/**
	 * Comprueba que una plantilla existe antes de asignarla.
	 *
	 * Asignar una plantilla inexistente deja la página en blanco, así que ante
	 * la duda se devuelve la predeterminada.
	 *
	 * @param string $plantilla Archivo de plantilla.
	 * @return string
	 */
	public static function validar_plantilla( $plantilla ) {
		$plantilla = sanitize_text_field( (string) $plantilla );

		if ( '' === $plantilla || 'default' === $plantilla ) {
			return '';
		}

		return array_key_exists( $plantilla, self::plantillas_disponibles() ) ? $plantilla : '';
	}

	/**
	 * Escribe metadatos desde otro módulo, respetando la misma lista blanca.
	 *
	 * Existe para que el módulo de WooCommerce no duplique la lógica de
	 * validación: una sola lista blanca, un solo sitio donde revisarla.
	 *
	 * @param int   $post_id ID.
	 * @param array $meta    Pares clave/valor.
	 * @return array
	 */
	public function escribir_meta_publico( $post_id, array $meta ) {
		return $this->write_meta( $post_id, $meta );
	}

	/**
	 * Escribe metadatos respetando la lista blanca.
	 *
	 * @param int   $post_id ID.
	 * @param array $meta    Pares clave/valor.
	 * @return array Claves efectivamente escritas y rechazadas.
	 */
	protected function write_meta( $post_id, array $meta ) {
		$prefijos  = self::allowed_meta_prefixes();
		$escritas  = array();
		$rechazadas = array();

		foreach ( $meta as $clave => $valor ) {
			$clave    = (string) $clave;
			$permitida = false;

			foreach ( $prefijos as $prefijo ) {
				if ( 0 === strpos( $clave, $prefijo ) ) {
					$permitida = true;
					break;
				}
			}

			if ( ! $permitida ) {
				$rechazadas[] = $clave;
				continue;
			}

			// `_elementor_data` debe guardarse con barras escapadas o WordPress
			// las elimina al pasar por update_post_meta.
			if ( '_elementor_data' === $clave && is_string( $valor ) ) {
				update_post_meta( $post_id, $clave, wp_slash( $valor ) );
			} else {
				update_post_meta( $post_id, $clave, $valor );
			}

			$escritas[] = $clave;
		}

		return array(
			'escritas'   => $escritas,
			'rechazadas' => $rechazadas,
		);
	}

	/**
	 * Limpia el contenido entrante.
	 *
	 * Se conserva el marcado de bloques y de constructores, pero se eliminan
	 * scripts y controladores de eventos.
	 *
	 * @param string $contenido HTML.
	 * @return string
	 */
	protected function sanitize_content( $contenido ) {
		$contenido = (string) $contenido;
		$contenido = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $contenido );
		$contenido = preg_replace( '#<iframe\b[^>]*>.*?</iframe>#is', '', $contenido );
		$contenido = preg_replace( '#\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\')#i', '', $contenido );
		return $contenido;
	}

	/**
	 * Sube un archivo a la biblioteca de medios.
	 *
	 * @param string $nombre    Nombre de archivo propuesto.
	 * @param string $contenido Contenido binario ya decodificado.
	 * @param string $alt       Texto alternativo.
	 * @return array|WP_Error
	 */
	public function upload_media( $nombre, $contenido, $alt = '' ) {
		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return new WP_Error(
				'appseo_read_only',
				__( 'Este sitio está en modo solo lectura.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$nombre    = sanitize_file_name( $nombre );
		$comprobado = wp_check_filetype( $nombre, self::allowed_mimes() );

		if ( empty( $comprobado['type'] ) ) {
			return new WP_Error(
				'appseo_mime_no_permitido',
				__( 'Ese tipo de archivo no está permitido.', 'appseo-ryf' ),
				array( 'status' => 415 )
			);
		}

		$subida = wp_upload_bits( $nombre, null, $contenido );

		if ( ! empty( $subida['error'] ) ) {
			return new WP_Error( 'appseo_upload_failed', $subida['error'], array( 'status' => 500 ) );
		}

		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $comprobado['type'],
				'post_title'     => sanitize_text_field( pathinfo( $nombre, PATHINFO_FILENAME ) ),
				'post_status'    => 'inherit',
				'post_author'    => AppSEO_RyF_Settings::acting_user_id(),
			),
			$subida['file']
		);

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		wp_update_attachment_metadata(
			$attachment_id,
			wp_generate_attachment_metadata( $attachment_id, $subida['file'] )
		);

		if ( '' !== $alt ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
		}

		AppSEO_RyF_Log::anotar(
			'medio_subir',
			array(
				'tipo'    => 'attachment',
				'id'      => (int) $attachment_id,
				'resumen' => sprintf(
					/* translators: 1: nombre de archivo, 2: tamaño en KB. */
					__( '%1$s (%2$s KB)', 'appseo-ryf' ),
					$nombre,
					number_format_i18n( strlen( $contenido ) / 1024, 1 )
				),
			)
		);

		return array(
			'id'   => (int) $attachment_id,
			'url'  => wp_get_attachment_url( $attachment_id ),
			'mime' => $comprobado['type'],
		);
	}
}
