<?php
/**
 * Descripción SEO al pie de las categorías de producto.
 *
 * Portado desde un fragmento suelto que vivía en Code Snippets. Se conserva la
 * misma clave de meta (`seconddesc`) y el mismo nombre de shortcode, de modo
 * que retirar aquel fragmento no cambia nada de lo ya escrito.
 *
 * El campo es un editor enriquecido y nada más: lo que se escriba dentro —
 * encabezados, tablas, un bloque de preguntas frecuentes— es HTML libre. Eso
 * evita imponer una estructura que cada tienda acabaría peleando.
 *
 * Por la misma razón, los estilos de esa sección no van escritos en el plugin
 * sino en un campo de los ajustes: la paleta y la tipografía cambian en cada
 * cliente, y un CSS fijo obligaría a tocar el código para cada tienda nueva.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Descripción SEO por categoría de producto.
 */
class AppSEO_RyF_Categorias {

	/** Meta con la descripción SEO. La clave viene del fragmento original. */
	const META_DESC = 'seconddesc';

	/** Para no repetir el CSS si la sección se pinta más de una vez. */
	protected static $css_pintado = false;

	/**
	 * Engancha todo, si el módulo está activo.
	 */
	public function register() {
		if ( ! AppSEO_RyF_Settings::get( 'seo_categorias', 0 ) ) {
			return;
		}

		// Si el fragmento original sigue activo, este módulo se aparta. Dos
		// copias del mismo código imprimirían el texto por duplicado, y es
		// mejor no hacer nada que ensuciar la tienda durante el cambio.
		if ( function_exists( 'dl_mostrar_desc_seo_cat' ) ) {
			return;
		}

		add_action( 'product_cat_add_form_fields', array( $this, 'campos_alta' ) );
		add_action( 'product_cat_edit_form_fields', array( $this, 'campos_edicion' ) );
		add_action( 'created_product_cat', array( $this, 'guardar' ) );
		add_action( 'edited_product_cat', array( $this, 'guardar' ) );

		add_action( 'woocommerce_after_shop_loop', array( $this, 'pintar' ), 5 );

		add_shortcode( 'mostrar_seo_cat', array( $this, 'shortcode' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Administración                                                      */
	/* ------------------------------------------------------------------ */

	/**
	 * Ajustes del editor enriquecido.
	 *
	 * @return array
	 */
	protected function ajustes_editor() {
		return array(
			'textarea_name' => self::META_DESC,
			'media_buttons' => true,
			'textarea_rows' => 12,
			'teeny'         => false,
			'quicktags'     => true,
		);
	}

	/**
	 * Campo al crear una categoría.
	 *
	 * @return void
	 */
	public function campos_alta() {
		?>
		<div class="form-field term-group">
			<label for="<?php echo esc_attr( self::META_DESC ); ?>"><?php esc_html_e( 'Descripción SEO', 'appseo-ryf' ); ?></label>
			<?php
			wp_nonce_field( 'appseo_seo_cat', 'appseo_seo_cat_nonce' );
			wp_editor( '', self::META_DESC, $this->ajustes_editor() );
			?>
			<p class="description"><?php esc_html_e( 'Se muestra al final de la página de categoría, debajo de los productos. Admite HTML: encabezados, listas, tablas y bloques de preguntas frecuentes.', 'appseo-ryf' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Campo al editar una categoría.
	 *
	 * @param WP_Term $term Término en edición.
	 * @return void
	 */
	public function campos_edicion( $term ) {
		$desc = get_term_meta( $term->term_id, self::META_DESC, true );
		?>
		<tr class="form-field term-group-wrap">
			<th scope="row"><label for="<?php echo esc_attr( self::META_DESC ); ?>"><?php esc_html_e( 'Descripción SEO', 'appseo-ryf' ); ?></label></th>
			<td>
				<?php
				wp_nonce_field( 'appseo_seo_cat', 'appseo_seo_cat_nonce' );
				wp_editor( htmlspecialchars_decode( (string) $desc ), self::META_DESC, $this->ajustes_editor() );
				?>
				<p class="description"><?php esc_html_e( 'Se muestra al final de la página de categoría, debajo de los productos. Admite HTML: encabezados, listas, tablas y bloques de preguntas frecuentes.', 'appseo-ryf' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Guarda la descripción.
	 *
	 * @param int $term_id Término guardado.
	 * @return void
	 */
	public function guardar( $term_id ) {
		if ( ! current_user_can( 'manage_product_terms' ) && ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		$nonce = isset( $_POST['appseo_seo_cat_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['appseo_seo_cat_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'appseo_seo_cat' ) ) {
			return;
		}

		if ( ! isset( $_POST[ self::META_DESC ] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wp_kses_post es la sanitización.
		$desc = wp_kses_post( wp_unslash( $_POST[ self::META_DESC ] ) );

		if ( '' === trim( wp_strip_all_tags( $desc ) ) ) {
			delete_term_meta( $term_id, self::META_DESC );
		} else {
			update_term_meta( $term_id, self::META_DESC, $desc );
		}

		AppSEO_RyF_Log::anotar(
			'categoria_seo',
			array(
				'tipo'    => 'product_cat',
				'id'      => $term_id,
				'resumen' => sprintf(
					/* translators: %s: número de caracteres. */
					__( 'Descripción SEO de categoría guardada (%s caracteres).', 'appseo-ryf' ),
					number_format_i18n( strlen( $desc ) )
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Lectura                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * Descripción SEO de un término.
	 *
	 * @param int $term_id Término.
	 * @return string
	 */
	public function leer( $term_id ) {
		return htmlspecialchars_decode( (string) get_term_meta( $term_id, self::META_DESC, true ) );
	}

	/* ------------------------------------------------------------------ */
	/* Salida pública                                                      */
	/* ------------------------------------------------------------------ */

	/**
	 * Descripción SEO bajo el listado de productos.
	 *
	 * @return void
	 */
	public function pintar() {
		if ( ! function_exists( 'is_product_taxonomy' ) || ! is_product_taxonomy() || is_checkout() ) {
			return;
		}

		$termino = get_queried_object();
		if ( ! $termino || empty( $termino->term_id ) ) {
			return;
		}

		// A partir de la segunda página el mismo texto aparecería en varias
		// URLs de la misma categoría, que es lo que un buscador lee como
		// contenido duplicado dentro del propio sitio.
		if ( AppSEO_RyF_Settings::get( 'seo_categorias_solo_pagina_1', 1 ) && $this->es_paginada() ) {
			return;
		}

		$desc = $this->leer( $termino->term_id );
		if ( '' === trim( wp_strip_all_tags( $desc ) ) ) {
			return;
		}

		echo $this->css(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ya saneado en css().
		echo '<div class="appseo-cat-seo term-description">' . wp_kses_post( $desc ) . '</div>';
	}

	/**
	 * ¿Estamos en la segunda página o siguientes del listado?
	 *
	 * @return bool
	 */
	protected function es_paginada() {
		$pagina = max(
			(int) get_query_var( 'paged' ),
			(int) get_query_var( 'page' ),
			(int) get_query_var( 'product-page' )
		);

		return $pagina > 1;
	}

	/**
	 * CSS de la sección, tomado de los ajustes.
	 *
	 * Va aquí y no en una hoja del plugin porque cada tienda tiene su paleta y
	 * su tipografía. Un CSS fijo obligaría a modificar el código del conector
	 * cada vez que se conecta un cliente nuevo.
	 *
	 * @return string
	 */
	protected function css() {
		if ( self::$css_pintado ) {
			return '';
		}

		$css = (string) AppSEO_RyF_Settings::get( 'seo_categorias_css', '' );
		if ( '' === trim( $css ) ) {
			return '';
		}

		self::$css_pintado = true;

		return '<style id="appseo-cat-seo-css">' . self::sanear_css( $css ) . '</style>';
	}

	/**
	 * Limpia lo que no debe viajar dentro de una hoja de estilos.
	 *
	 * El CSS no ejecuta código por sí mismo, pero una cadena que cierre la
	 * etiqueta `<style>` sí permitiría inyectar marcado en la página.
	 *
	 * @param string $css Hoja de estilos.
	 * @return string
	 */
	public static function sanear_css( $css ) {
		$css = preg_replace( '#</\s*style#i', '', (string) $css );
		$css = preg_replace( '#<\s*script#i', '', $css );
		$css = preg_replace( '#javascript\s*:#i', '', $css );
		$css = preg_replace( '#expression\s*\(#i', '(', $css );

		return trim( $css );
	}

	/**
	 * Shortcode `[mostrar_seo_cat]`.
	 *
	 * Se mantiene el nombre del fragmento original para que las páginas que ya
	 * lo usan sigan funcionando.
	 *
	 * @param array $atts Atributos.
	 * @return string
	 */
	public function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'mostrar_seo_cat' );

		$term_id = $atts['id'] ? (int) $atts['id'] : get_queried_object_id();
		if ( ! $term_id ) {
			return '';
		}

		$desc = $this->leer( $term_id );
		if ( '' === trim( wp_strip_all_tags( $desc ) ) ) {
			return '';
		}

		return $this->css() . '<div class="appseo-cat-seo term-description-seo">' . wp_kses_post( $desc ) . '</div>';
	}

	/**
	 * CSS base que trae el plugin.
	 *
	 * Sirve de punto de partida: se copia al campo de los ajustes la primera
	 * vez que se activa el módulo. A partir de ahí manda lo guardado en el
	 * sitio, así que editarlo o vaciarlo nunca se deshace en la actualización
	 * siguiente.
	 *
	 * @return string
	 */
	public static function css_base() {
		$ruta = APPSEO_RYF_DIR . 'assets/categoria-base.css';

		if ( ! is_readable( $ruta ) ) {
			return '';
		}

		return (string) file_get_contents( $ruta ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Copia el CSS base al campo de ajustes si nunca se ha guardado nada.
	 *
	 * Se comprueba la presencia de la clave, no que tenga contenido: si
	 * alguien vació el campo a propósito, esa decisión se respeta.
	 *
	 * @return void
	 */
	public static function sembrar_css() {
		$guardado = get_option( APPSEO_RYF_OPTION, array() );

		if ( is_array( $guardado ) && array_key_exists( 'seo_categorias_css', $guardado ) ) {
			return;
		}

		AppSEO_RyF_Settings::update( array( 'seo_categorias_css' => self::css_base() ) );
	}

	/**
	 * Estado del módulo, para la pantalla de ajustes y para el panel.
	 *
	 * @return array
	 */
	public static function estado() {
		return array(
			'activo'           => (bool) AppSEO_RyF_Settings::get( 'seo_categorias', 0 ),
			'fragmento_activo' => function_exists( 'dl_mostrar_desc_seo_cat' ),
			'con_css'          => '' !== trim( (string) AppSEO_RyF_Settings::get( 'seo_categorias_css', '' ) ),
			'woocommerce'      => class_exists( 'WooCommerce' ),
		);
	}
}
