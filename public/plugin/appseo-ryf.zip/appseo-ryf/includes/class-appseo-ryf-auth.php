<?php
/**
 * Autenticación de las peticiones del panel mediante firma HMAC.
 *
 * El secreto compartido nunca viaja en la petición: se usa para firmar. Así no
 * queda registrado en logs de servidor, proxies ni cabeceras intermedias.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Verificación de firmas.
 */
class AppSEO_RyF_Auth {

	/** Margen de desfase horario aceptado, en segundos. */
	const MAX_SKEW = 300;

	/** Tiempo que se recuerda un nonce para impedir reenvíos, en segundos. */
	const NONCE_TTL = 900;

	/** Prefijo de los transients de nonce. */
	const NONCE_PREFIX = 'appseo_nonce_';

	/**
	 * Genera un identificador de clave público (no secreto).
	 *
	 * @return string
	 */
	public static function generate_key_id() {
		return 'ak_' . bin2hex( random_bytes( 8 ) );
	}

	/**
	 * Genera el secreto compartido.
	 *
	 * @return string
	 */
	public static function generate_secret() {
		return bin2hex( random_bytes( 32 ) );
	}

	/**
	 * Cadena de conexión que el usuario copia en el panel.
	 *
	 * Contiene la URL del sitio, el identificador de clave y el secreto. Es
	 * sensible: quien la tenga puede operar el sitio dentro de los límites
	 * configurados.
	 *
	 * @return string
	 */
	public static function connection_string() {
		$settings = AppSEO_RyF_Settings::all();

		$payload = wp_json_encode(
			array(
				'v'      => 1,
				'site'   => untrailingslashit( home_url() ),
				'rest'   => untrailingslashit( rest_url( APPSEO_RYF_NAMESPACE ) ),
				'key_id' => $settings['key_id'],
				'secret' => $settings['secret'],
			)
		);

		return 'appseo_' . rtrim( strtr( base64_encode( $payload ), '+/', '-_' ), '=' );
	}

	/**
	 * Construye la cadena canónica que se firma.
	 *
	 * @param string $method    Método HTTP en mayúsculas.
	 * @param string $route     Ruta REST solicitada.
	 * @param string $timestamp Marca de tiempo Unix enviada por el cliente.
	 * @param string $nonce     Valor único por petición.
	 * @param string $body      Cuerpo crudo de la petición.
	 * @return string
	 */
	public static function canonical_string( $method, $route, $timestamp, $nonce, $body ) {
		return implode(
			"\n",
			array(
				strtoupper( $method ),
				$route,
				$timestamp,
				$nonce,
				hash( 'sha256', (string) $body ),
			)
		);
	}

	/**
	 * Verifica la firma de una petición REST entrante.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return true|WP_Error
	 */
	public static function verify( WP_REST_Request $request ) {
		$settings = AppSEO_RyF_Settings::all();

		if ( empty( $settings['key_id'] ) || empty( $settings['secret'] ) ) {
			return new WP_Error(
				'appseo_not_configured',
				__( 'Este sitio todavía no tiene credenciales de conexión.', 'appseo-ryf' ),
				array( 'status' => 503 )
			);
		}

		$key_id    = (string) $request->get_header( 'x-appseo-key' );
		$timestamp = (string) $request->get_header( 'x-appseo-timestamp' );
		$nonce     = (string) $request->get_header( 'x-appseo-nonce' );
		$signature = (string) $request->get_header( 'x-appseo-signature' );

		if ( '' === $key_id || '' === $timestamp || '' === $nonce || '' === $signature ) {
			return new WP_Error(
				'appseo_missing_headers',
				__( 'Faltan cabeceras de autenticación.', 'appseo-ryf' ),
				array( 'status' => 401 )
			);
		}

		if ( ! hash_equals( $settings['key_id'], $key_id ) ) {
			return new WP_Error(
				'appseo_unknown_key',
				__( 'Identificador de clave desconocido.', 'appseo-ryf' ),
				array( 'status' => 401 )
			);
		}

		if ( ! ctype_digit( $timestamp ) ) {
			return new WP_Error(
				'appseo_bad_timestamp',
				__( 'Marca de tiempo inválida.', 'appseo-ryf' ),
				array( 'status' => 401 )
			);
		}

		$skew = abs( time() - (int) $timestamp );
		if ( $skew > self::MAX_SKEW ) {
			return new WP_Error(
				'appseo_stale_request',
				sprintf(
					/* translators: %d: segundos de desfase permitidos. */
					__( 'La petición está fuera de la ventana de %d segundos. Revisa el reloj del servidor.', 'appseo-ryf' ),
					self::MAX_SKEW
				),
				array( 'status' => 401 )
			);
		}

		if ( ! preg_match( '/^[A-Za-z0-9_-]{16,128}$/', $nonce ) ) {
			return new WP_Error(
				'appseo_bad_nonce',
				__( 'Nonce con formato inválido.', 'appseo-ryf' ),
				array( 'status' => 401 )
			);
		}

		$nonce_key = self::NONCE_PREFIX . hash( 'sha256', $nonce );
		if ( false !== get_transient( $nonce_key ) ) {
			return new WP_Error(
				'appseo_replay',
				__( 'Esta petición ya se había recibido.', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}

		$canonical = self::canonical_string(
			$request->get_method(),
			$request->get_route(),
			$timestamp,
			$nonce,
			$request->get_body()
		);

		$expected = hash_hmac( 'sha256', $canonical, $settings['secret'] );

		if ( ! hash_equals( $expected, $signature ) ) {
			return new WP_Error(
				'appseo_bad_signature',
				__( 'La firma no coincide.', 'appseo-ryf' ),
				array( 'status' => 401 )
			);
		}

		set_transient( $nonce_key, 1, self::NONCE_TTL );

		AppSEO_RyF_Settings::update(
			array(
				'last_seen' => time(),
				'last_ip'   => self::client_ip(),
			)
		);

		return true;
	}

	/**
	 * IP del cliente, solo para mostrarla en los ajustes.
	 *
	 * No se usa para tomar decisiones de seguridad, porque es falsificable
	 * detrás de proxies.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$raw = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';
		$ip  = filter_var( $raw, FILTER_VALIDATE_IP );
		return $ip ? $ip : '';
	}
}
