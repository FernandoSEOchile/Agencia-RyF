<?php
/**
 * Acceso centralizado a la configuración del plugin.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Lectura y escritura de la única opción del plugin.
 */
class AppSEO_RyF_Settings {

	/**
	 * Valores por defecto.
	 *
	 * `read_only` arranca en 1 a propósito: un sitio recién conectado nunca
	 * debe aceptar escrituras hasta que alguien lo autorice explícitamente.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'key_id'                  => '',
			'secret'                  => '',
			'read_only'               => 1,
			'allow_publish'           => 0,
			'allow_plugin_management' => 0,
			'allow_price_writes'      => 0,
			'auto_actualizar'              => 0,
			'seo_categorias'               => 0,
			'seo_categorias_solo_pagina_1' => 1,
			'seo_categorias_css'           => '',
			'meta_desc_categoria'          => '',
			'meta_faqs_categoria'          => '',
			'plugin_allowlist'        => array(),
			'acting_user'             => 0,
			'paired_at'               => 0,
			'last_seen'               => 0,
			'last_ip'                 => '',
		);
	}

	/**
	 * Dónde guarda ESTE sitio la descripción SEO de una categoría.
	 *
	 * Hay tiendas con su propio desarrollo a medida, hecho antes de que
	 * existiera el conector, que ya guardan ese texto bajo su propia clave y lo
	 * pintan con su propia plantilla. Si el panel escribiera siempre en la suya,
	 * el texto se guardaría bien y no se vería nunca — el peor fallo posible,
	 * porque nadie se entera.
	 *
	 * Configurable en vez de una excepción en el código: la alternativa era un
	 * «si el sitio es tal, usa tal clave», y esas condiciones nadie se atreve a
	 * borrarlas dos años después.
	 *
	 * @return string
	 */
	public static function meta_desc() {
		$k = trim( (string) self::get( 'meta_desc_categoria', '' ) );
		return $k !== '' ? $k : AppSEO_RyF_Categorias::META_DESC;
	}

	/**
	 * Dónde guarda este sitio las preguntas frecuentes de una categoría.
	 *
	 * Vacío significa que no guarda ninguna, y entonces el panel ni las lee ni
	 * las escribe. No hay clave por defecto porque el conector todavía no tiene
	 * FAQ propias: esto existe para hablar con las que ya tenga la tienda.
	 *
	 * @return string
	 */
	public static function meta_faqs() {
		return trim( (string) self::get( 'meta_faqs_categoria', '' ) );
	}

	/**
	 * Devuelve la configuración completa, con los valores por defecto aplicados.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( APPSEO_RYF_OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return wp_parse_args( $saved, self::defaults() );
	}

	/**
	 * Devuelve un único valor de configuración.
	 *
	 * @param string $key     Clave.
	 * @param mixed  $default Valor si no existe.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Fusiona y guarda cambios en la configuración.
	 *
	 * @param array $changes Pares clave/valor a actualizar.
	 * @return void
	 */
	public static function update( array $changes ) {
		$merged = array_merge( self::all(), $changes );
		update_option( APPSEO_RYF_OPTION, $merged, false );
	}

	/**
	 * ¿Está el sitio en modo solo lectura?
	 *
	 * @return bool
	 */
	public static function is_read_only() {
		return (bool) self::get( 'read_only', 1 );
	}

	/**
	 * Usuario bajo el que se atribuyen las escrituras.
	 *
	 * Si no hay uno válido configurado, se devuelve 0 y las escrituras se
	 * rechazan: preferimos fallar antes que crear contenido huérfano.
	 *
	 * @return int
	 */
	public static function acting_user_id() {
		$id = (int) self::get( 'acting_user', 0 );
		if ( $id <= 0 ) {
			return 0;
		}
		$user = get_user_by( 'id', $id );
		if ( ! $user || ! user_can( $user, 'edit_posts' ) ) {
			return 0;
		}
		return $id;
	}
}
