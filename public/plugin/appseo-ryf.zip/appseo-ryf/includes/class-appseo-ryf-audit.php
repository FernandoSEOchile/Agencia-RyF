<?php
/**
 * Cálculo de la auditoría de contenido en el propio servidor del sitio.
 *
 * La razón de ser de este plugin: en lugar de que el panel descargue el
 * contenido íntegro de cientos de páginas para analizarlo, el análisis se hace
 * aquí y viaja un resumen compacto.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Recolector de datos de auditoría.
 */
class AppSEO_RyF_Audit {

	/** Tope de piezas analizadas por defecto. */
	const DEFAULT_LIMIT = 500;

	/** Tope absoluto, para no tumbar sitios grandes. */
	const MAX_LIMIT = 2000;

	/**
	 * Ejecuta la auditoría.
	 *
	 * @param array $args {
	 *     @type int    $limit          Máximo de piezas a analizar.
	 *     @type string $modified_after Fecha ISO 8601; solo piezas modificadas después.
	 *     @type bool   $include_links  Calcular el grafo de enlaces internos.
	 * }
	 * @return array
	 */
	public function collect( array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'limit'          => self::DEFAULT_LIMIT,
				'modified_after' => '',
				'include_links'  => true,
			)
		);

		$limit = max( 1, min( self::MAX_LIMIT, (int) $args['limit'] ) );

		$query_args = array(
			'post_type'              => array( 'page', 'post' ),
			'post_status'            => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page'         => $limit,
			'orderby'                => 'modified',
			'order'                  => 'DESC',
			'no_found_rows'          => false,
			'ignore_sticky_posts'    => true,
			'update_post_term_cache' => true,
			'update_post_meta_cache' => true,
		);

		if ( ! empty( $args['modified_after'] ) ) {
			$query_args['date_query'] = array(
				array(
					'column' => 'post_modified_gmt',
					'after'  => sanitize_text_field( $args['modified_after'] ),
				),
			);
		}

		$query = new WP_Query( $query_args );
		$posts = $query->posts;

		$items    = array();
		$textos   = array();
		$permalinks = array();

		foreach ( $posts as $post ) {
			$row = $this->build_row( $post );
			$items[] = $row;
			$permalinks[ $this->normalize_url( $row['url'] ) ] = $post->ID;
			$textos[ $post->ID ] = $this->raw_markup( $post );
		}

		$links = array();
		if ( $args['include_links'] ) {
			$links = $this->build_link_graph( $textos, $permalinks );
		}

		return array(
			'generated_at' => gmdate( 'c' ),
			'site'         => $this->site_info(),
			'content'      => $items,
			'links'        => $links,
			'taxonomies'   => $this->taxonomy_info(),
			'menus'        => $this->menu_info(),
			'truncated'    => array(
				'limit'      => $limit,
				'total'      => (int) $query->found_posts,
				'was_capped' => (int) $query->found_posts > $limit,
			),
		);
	}

	/**
	 * Datos generales del sitio y su entorno.
	 *
	 * @return array
	 */
	protected function site_info() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = array();
		foreach ( get_plugins() as $file => $data ) {
			$plugins[] = array(
				'nombre'  => $data['Name'],
				'version' => $data['Version'],
				'activo'  => is_plugin_active( $file ),
			);
		}

		$theme = wp_get_theme();

		return array(
			'nombre'       => get_bloginfo( 'name' ),
			'descripcion'  => get_bloginfo( 'description' ),
			'url'          => home_url(),
			'wordpress'    => get_bloginfo( 'version' ),
			'php'          => PHP_VERSION,
			'locale'       => get_locale(),
			'zona_horaria' => wp_timezone_string(),
			'tema'         => array(
				'nombre'  => $theme->get( 'Name' ),
				'version' => $theme->get( 'Version' ),
				'hijo'    => (bool) $theme->parent(),
			),
			'plugins'      => $plugins,
			'portada'      => array(
				'muestra'     => get_option( 'show_on_front' ),
				'pagina_id'   => (int) get_option( 'page_on_front' ),
				'entradas_id' => (int) get_option( 'page_for_posts' ),
			),
			'plantillas'   => AppSEO_RyF_Content::plantillas_disponibles(),
			'conector'     => APPSEO_RYF_VERSION,
		);
	}

	/**
	 * Convierte una entrada en su fila de auditoría.
	 *
	 * @param WP_Post $post Entrada.
	 * @return array
	 */
	protected function build_row( WP_Post $post ) {
		$texto    = wp_strip_all_tags( $this->raw_markup( $post ) );
		$palabras = $this->count_words( $texto );

		$categorias = array();
		if ( 'post' === $post->post_type ) {
			foreach ( wp_get_post_categories( $post->ID ) as $term_id ) {
				$term = get_term( $term_id, 'category' );
				if ( $term && ! is_wp_error( $term ) ) {
					$categorias[] = $term->name;
				}
			}
		}

		return array(
			'id'          => $post->ID,
			'titulo'      => $post->post_title,
			'slug'        => $post->post_name,
			'url'         => get_permalink( $post->ID ),
			'tipo'        => $post->post_type,
			'estado'      => $post->post_status,
			'parent'      => (int) $post->post_parent,
			'autor'       => (int) $post->post_author,
			'creado'      => get_the_date( 'Y-m-d', $post->ID ),
			'modificado'  => get_the_modified_date( 'Y-m-d', $post->ID ),
			'palabras'    => $palabras,
			'extracto'    => (bool) trim( $post->post_excerpt ),
			'destacada'   => has_post_thumbnail( $post->ID ),
			'editor'      => $this->detect_editor( $post ),
			'categorias'  => $categorias,
			'seo'         => $this->seo_meta( $post->ID ),
			'marcadores'  => $this->detect_placeholder( $texto ),
		);
	}

	/**
	 * Devuelve el marcado completo, incluido el de Elementor si lo hay.
	 *
	 * @param WP_Post $post Entrada.
	 * @return string
	 */
	protected function raw_markup( WP_Post $post ) {
		$markup = (string) $post->post_content;

		if ( 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
			$data = get_post_meta( $post->ID, '_elementor_data', true );
			if ( is_string( $data ) && '' !== $data ) {
				// El JSON de Elementor lleva las barras escapadas; se deshace
				// para que los enlaces internos se detecten correctamente.
				$markup .= ' ' . str_replace( array( '\\/', '\\"' ), array( '/', '"' ), $data );
			}
		}

		return $markup;
	}

	/**
	 * Cuenta palabras de forma fiable con acentos y eñes.
	 *
	 * `str_word_count` de PHP no entiende UTF-8 y descuadra en español.
	 *
	 * @param string $texto Texto plano.
	 * @return int
	 */
	protected function count_words( $texto ) {
		$texto = trim( preg_replace( '/\s+/u', ' ', $texto ) );
		if ( '' === $texto ) {
			return 0;
		}
		return count( preg_split( '/\s+/u', $texto ) );
	}

	/**
	 * Identifica con qué editor se construyó la pieza.
	 *
	 * @param WP_Post $post Entrada.
	 * @return string
	 */
	protected function detect_editor( WP_Post $post ) {
		if ( 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
			return 'elementor';
		}
		if ( has_blocks( $post->post_content ) ) {
			return 'gutenberg';
		}
		return 'clasico';
	}

	/**
	 * Metadatos SEO, si hay un plugin compatible.
	 *
	 * @param int $post_id ID.
	 * @return array
	 */
	protected function seo_meta( $post_id ) {
		$focus   = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
		$desc    = get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );
		$titulo  = get_post_meta( $post_id, '_yoast_wpseo_title', true );
		$noindex = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );

		// Rank Math, como alternativa habitual a Yoast.
		if ( '' === $focus ) {
			$focus = get_post_meta( $post_id, 'rank_math_focus_keyword', true );
		}
		if ( '' === $desc ) {
			$desc = get_post_meta( $post_id, 'rank_math_description', true );
		}

		return array(
			'keyword'  => is_string( $focus ) ? $focus : '',
			'metadesc' => is_string( $desc ) ? $desc : '',
			'titulo'   => is_string( $titulo ) ? $titulo : '',
			'noindex'  => ( '1' === $noindex ),
		);
	}

	/**
	 * Detecta texto de relleno sin publicar.
	 *
	 * Nace de un caso real: una página de servicios llevaba años publicada con
	 * lorem ipsum de la plantilla original.
	 *
	 * @param string $texto Texto plano.
	 * @return array Marcadores encontrados.
	 */
	protected function detect_placeholder( $texto ) {
		$agujas = apply_filters(
			'appseo_ryf_placeholder_needles',
			array(
				'lorem ipsum',
				'dolor sit amet',
				'consectetur adipiscing',
				'vivamus integer',
				'mollis pretium',
				'sed do eiusmod',
				'texto de ejemplo',
				'escribe aquí tu',
			)
		);

		$bajo        = function_exists( 'mb_strtolower' ) ? mb_strtolower( $texto, 'UTF-8' ) : strtolower( $texto );
		$encontrados = array();

		foreach ( $agujas as $aguja ) {
			if ( false !== strpos( $bajo, $aguja ) ) {
				$encontrados[] = $aguja;
			}
		}

		return $encontrados;
	}

	/**
	 * Construye el grafo de enlaces internos.
	 *
	 * @param array $markup     Mapa id => marcado.
	 * @param array $permalinks Mapa url normalizada => id.
	 * @return array Lista de pares desde/hacia.
	 */
	protected function build_link_graph( array $markup, array $permalinks ) {
		$host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$home   = untrailingslashit( home_url() );
		$aristas = array();

		foreach ( $markup as $post_id => $html ) {
			if ( ! preg_match_all( '#href=(?:\\\\?["\'])([^"\'\\\\]+)#i', $html, $m ) ) {
				continue;
			}

			$vistos = array();

			foreach ( $m[1] as $href ) {
				$href = html_entity_decode( str_replace( '\\/', '/', $href ), ENT_QUOTES, 'UTF-8' );

				$href_host = wp_parse_url( $href, PHP_URL_HOST );
				if ( null !== $href_host && $href_host !== $host ) {
					continue;
				}

				if ( 0 === strpos( $href, '/' ) ) {
					$href = $home . $href;
				}

				$limpio = $this->normalize_url( strtok( $href, '#?' ) );

				if ( isset( $permalinks[ $limpio ] ) && $permalinks[ $limpio ] !== $post_id ) {
					$vistos[ $permalinks[ $limpio ] ] = true;
				}
			}

			foreach ( array_keys( $vistos ) as $destino ) {
				$aristas[] = array(
					'desde' => (int) $post_id,
					'hacia' => (int) $destino,
				);
			}
		}

		return $aristas;
	}

	/**
	 * Normaliza una URL para poder compararla.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	protected function normalize_url( $url ) {
		$url = untrailingslashit( strtok( (string) $url, '#?' ) );
		return preg_replace( '#^https?://#i', '', $url );
	}

	/**
	 * Términos por taxonomía, con su recuento.
	 *
	 * @return array
	 */
	protected function taxonomy_info() {
		$salida = array();

		foreach ( array( 'category', 'post_tag' ) as $taxonomy ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			);

			if ( is_wp_error( $terms ) ) {
				continue;
			}

			$salida[ $taxonomy ] = array_map(
				static function ( $term ) {
					return array(
						'id'     => $term->term_id,
						'nombre' => $term->name,
						'slug'   => $term->slug,
						'total'  => $term->count,
					);
				},
				$terms
			);
		}

		return $salida;
	}

	/**
	 * Menús de navegación y sus entradas.
	 *
	 * @return array
	 */
	protected function menu_info() {
		$salida = array();

		foreach ( wp_get_nav_menus() as $menu ) {
			$entradas = wp_get_nav_menu_items( $menu->term_id );
			if ( ! $entradas ) {
				$entradas = array();
			}

			$salida[] = array(
				'nombre'   => $menu->name,
				'entradas' => array_map(
					static function ( $item ) {
						return array(
							'titulo'     => $item->title,
							'url'        => $item->url,
							'objeto_id'  => (int) $item->object_id,
							'parent'     => (int) $item->menu_item_parent,
						);
					},
					$entradas
				),
			);
		}

		return $salida;
	}
}
