<?php
/**
 * Interfaz de administración: menú propio, barra superior y ajustes.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pantallas y menús del conector.
 */
class AppSEO_RyF_Admin {

	/** Acción del formulario de ajustes. */
	const ACTION = 'appseo_ryf_guardar';

	/** Slug de la página principal. */
	const SLUG = 'appseo-ryf';

	/**
	 * Engancha los hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_save' ) );
		add_action( 'admin_bar_menu', array( $this, 'admin_bar' ), 80 );
		add_action( 'admin_head', array( $this, 'estilos_barra' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * Icono del menú, en SVG monocromo.
	 *
	 * @return string
	 */
	public static function icono_svg() {
		// Pensado para leerse a 20 px: formas macizas y pocas. Tres barras
		// ascendentes —posicionamiento que sube— y un nodo suelto arriba, que
		// lo distingue del icono de estadísticas del propio WordPress.
		// Todo va en negro opaco: al usarse como máscara CSS solo cuenta el
		// canal alfa, y el color real lo pone `background-color` desde fuera.
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="#000">'
			. '<rect x="2.4" y="11.6" width="3.6" height="6.2" rx="1.4"/>'
			. '<rect x="8.2" y="8" width="3.6" height="9.8" rx="1.4"/>'
			. '<rect x="14" y="10" width="3.6" height="7.8" rx="1.4"/>'
			. '<circle cx="15.8" cy="4.2" r="2.5"/>'
			. '<path d="M4.2 9.9 13.4 5.1" stroke="#000" stroke-width="1.6" stroke-linecap="round" fill="none"/>'
			. '</svg>';
	}

	/**
	 * El icono como data URI.
	 *
	 * @return string
	 */
	protected function icono_data_uri() {
		return 'data:image/svg+xml;base64,' . base64_encode( self::icono_svg() );
	}

	/**
	 * Registra el menú de primer nivel.
	 *
	 * @return void
	 */
	public function menu() {
		// `none` en lugar de un data URI: WordPress inserta el data URI como
		// <img>, donde el SVG se pinta con su propio fill y sale negro sobre el
		// menú oscuro. Con `none` deja un hueco vacío que rellenamos por CSS
		// con una máscara y `currentColor`, así el icono hereda exactamente el
		// mismo color que los nativos, incluidos los estados activo y hover.
		add_menu_page(
			__( 'AppSEO RyF', 'appseo-ryf' ),
			__( 'AppSEO', 'appseo-ryf' ),
			'manage_options',
			self::SLUG,
			array( $this, 'render' ),
			'none',
			58
		);

		add_submenu_page(
			self::SLUG,
			__( 'Conexión y permisos', 'appseo-ryf' ),
			__( 'Conexión', 'appseo-ryf' ),
			'manage_options',
			self::SLUG,
			array( $this, 'render' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Registro de actividad', 'appseo-ryf' ),
			__( 'Registro', 'appseo-ryf' ),
			'manage_options',
			self::SLUG . '-registro',
			array( $this, 'render_registro' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Alcance y estado', 'appseo-ryf' ),
			__( 'Alcance', 'appseo-ryf' ),
			'manage_options',
			self::SLUG . '-actividad',
			array( $this, 'render_actividad' )
		);
	}

	/**
	 * Carga los estilos y el script solo en las pantallas del plugin.
	 *
	 * @param string $hook Identificador de la pantalla actual.
	 * @return void
	 */
	public function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}

		$base = plugin_dir_url( APPSEO_RYF_FILE ) . 'assets/';

		wp_enqueue_style(
			'appseo-ryf-fuentes',
			'https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap',
			array(),
			null
		);

		wp_enqueue_style( 'appseo-ryf-admin', $base . 'admin.css', array(), APPSEO_RYF_VERSION );
		wp_enqueue_script( 'appseo-ryf-admin', $base . 'admin.js', array(), APPSEO_RYF_VERSION, true );
	}

	/**
	 * Nodo en la barra superior.
	 *
	 * @param WP_Admin_Bar $bar Barra.
	 * @return void
	 */
	public function admin_bar( $bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		list( $estado, $color ) = $this->estado_conexion();

		$bar->add_node(
			array(
				'id'    => 'appseo-ryf',
				'title' => '<span class="ab-icon appseo-ab-icon" aria-hidden="true"></span>'
					. '<span class="ab-label">AppSEO</span>'
					. '<span class="appseo-ab-punto" style="background:' . esc_attr( $color ) . '"></span>',
				'href'  => admin_url( 'admin.php?page=' . self::SLUG ),
				'meta'  => array( 'title' => 'AppSEO RyF — ' . $estado ),
			)
		);

		$bar->add_node(
			array(
				'parent' => 'appseo-ryf',
				'id'     => 'appseo-estado',
				'title'  => sprintf(
					/* translators: %s: estado de la conexión. */
					__( 'Estado: %s', 'appseo-ryf' ),
					$estado
				),
			)
		);

		$bar->add_node(
			array(
				'parent' => 'appseo-ryf',
				'id'     => 'appseo-ajustes',
				'title'  => __( 'Conexión y permisos', 'appseo-ryf' ),
				'href'   => admin_url( 'admin.php?page=' . self::SLUG ),
			)
		);
	}

	/**
	 * Estado legible de la conexión y su color.
	 *
	 * @return array{0:string,1:string}
	 */
	protected function estado_conexion() {
		$settings = AppSEO_RyF_Settings::all();

		if ( empty( $settings['last_seen'] ) ) {
			return array( __( 'sin conectar', 'appseo-ryf' ), '#ffb020' );
		}
		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return array( __( 'solo lectura', 'appseo-ryf' ), '#4aa3ff' );
		}
		return array( __( 'escritura activa', 'appseo-ryf' ), '#3ddc84' );
	}

	/**
	 * Estilos del icono en la barra superior.
	 *
	 * @return void
	 */
	public function estilos_barra() {
		$menu = is_admin();

		if ( ! $menu && ! is_admin_bar_showing() ) {
			return;
		}

		// `esc_url()` NO sirve aquí: descarta cualquier URI cuyo protocolo no
		// esté en wp_allowed_protocols(), y `data:` no lo está — devolvería
		// cadena vacía y la máscara se quedaría sin imagen. El valor lo genera
		// este mismo plugin a partir de un SVG fijo, así que no hay entrada de
		// usuario que escapar; se usa esc_attr para las comillas y basta.
		$uri  = esc_attr( $this->icono_data_uri() );
		$slug = esc_attr( self::SLUG );
		?>
		<style>
		<?php if ( $menu ) : ?>
			/* Icono del menú lateral: máscara sobre currentColor, para que siga
			   el color del escritorio igual que los iconos nativos. */
			#adminmenu .toplevel_page_<?php echo $slug; // phpcs:ignore WordPress.Security.EscapeOutput ?> .wp-menu-image::before{
				content:"";display:block;width:20px;height:20px;margin:7px auto 0;
				background-color:currentColor;
				-webkit-mask:url("<?php echo $uri; // phpcs:ignore WordPress.Security.EscapeOutput ?>") no-repeat center/20px 20px;
				mask:url("<?php echo $uri; // phpcs:ignore WordPress.Security.EscapeOutput ?>") no-repeat center/20px 20px}
			#adminmenu .toplevel_page_<?php echo $slug; // phpcs:ignore WordPress.Security.EscapeOutput ?> .wp-menu-image{
				color:#a7aaad}
			#adminmenu .toplevel_page_<?php echo $slug; // phpcs:ignore WordPress.Security.EscapeOutput ?>:hover .wp-menu-image,
			#adminmenu .toplevel_page_<?php echo $slug; // phpcs:ignore WordPress.Security.EscapeOutput ?>.wp-has-current-submenu .wp-menu-image,
			#adminmenu .toplevel_page_<?php echo $slug; // phpcs:ignore WordPress.Security.EscapeOutput ?>.current .wp-menu-image{
				color:#fff}
		<?php endif; ?>
		<?php if ( is_admin_bar_showing() ) : ?>
			#wpadminbar .appseo-ab-icon::before{content:"";display:block;width:18px;height:18px;margin-top:5px;
				background-color:currentColor;
				-webkit-mask:url("<?php echo $uri; // phpcs:ignore WordPress.Security.EscapeOutput ?>") no-repeat center/18px 18px;
				mask:url("<?php echo $uri; // phpcs:ignore WordPress.Security.EscapeOutput ?>") no-repeat center/18px 18px}
			#wpadminbar .appseo-ab-punto{display:inline-block;width:7px;height:7px;border-radius:50%;
				margin-left:6px;vertical-align:middle}
		<?php endif; ?>
		</style>
		<?php
	}

	/**
	 * Procesa el guardado.
	 *
	 * @return void
	 */
	public function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos para hacer esto.', 'appseo-ryf' ) );
		}

		check_admin_referer( self::ACTION );

		$lista = array();
		if ( isset( $_POST['plugin_allowlist'] ) ) {
			$crudo = sanitize_textarea_field( wp_unslash( $_POST['plugin_allowlist'] ) );
			foreach ( preg_split( '/[\s,]+/', $crudo ) as $slug ) {
				$slug = sanitize_key( $slug );
				if ( '' !== $slug ) {
					$lista[] = $slug;
				}
			}
		}

		// El interruptor pregunta en positivo («permitir cambios»), pero por
		// dentro se sigue guardando `read_only` para no romper instalaciones
		// anteriores.
		$cambios = array(
			'read_only'               => isset( $_POST['allow_writes'] ) ? 0 : 1,
			'allow_publish'           => isset( $_POST['allow_publish'] ) ? 1 : 0,
			'allow_price_writes'      => isset( $_POST['allow_price_writes'] ) ? 1 : 0,
			'allow_plugin_management' => isset( $_POST['allow_plugin_management'] ) ? 1 : 0,
			'auto_actualizar'         => isset( $_POST['auto_actualizar'] ) ? 1 : 0,
			'seo_categorias'          => isset( $_POST['seo_categorias'] ) ? 1 : 0,
			'seo_categorias_solo_pagina_1' => isset( $_POST['seo_categorias_solo_pagina_1'] ) ? 1 : 0,
			'seo_categorias_css'      => isset( $_POST['seo_categorias_css'] )
				? AppSEO_RyF_Categorias::sanear_css( wp_unslash( $_POST['seo_categorias_css'] ) )
				: '',
			'meta_desc_categoria'     => isset( $_POST['meta_desc_categoria'] )
				? sanitize_key( wp_unslash( $_POST['meta_desc_categoria'] ) )
				: '',
			'meta_faqs_categoria'     => isset( $_POST['meta_faqs_categoria'] )
				? sanitize_key( wp_unslash( $_POST['meta_faqs_categoria'] ) )
				: '',
			'plugin_allowlist'        => array_values( array_unique( $lista ) ),
			'acting_user'             => isset( $_POST['acting_user'] ) ? absint( wp_unslash( $_POST['acting_user'] ) ) : 0,
		);

		if ( isset( $_POST['regenerar'] ) ) {
			$cambios['key_id'] = AppSEO_RyF_Auth::generate_key_id();
			$cambios['secret'] = AppSEO_RyF_Auth::generate_secret();
		}

		AppSEO_RyF_Settings::update( $cambios );

		if ( isset( $_POST['regenerar'] ) ) {
			AppSEO_RyF_Log::anotar(
				'credenciales_nuevas',
				array( 'resumen' => __( 'La conexión anterior quedó invalidada', 'appseo-ryf' ) )
			);
		} else {
			$activos = array();
			if ( ! $cambios['read_only'] ) {
				$activos[] = __( 'contenido', 'appseo-ryf' );
			}
			if ( $cambios['allow_publish'] ) {
				$activos[] = __( 'publicación', 'appseo-ryf' );
			}
			if ( $cambios['allow_price_writes'] ) {
				$activos[] = __( 'precios', 'appseo-ryf' );
			}
			if ( $cambios['allow_plugin_management'] ) {
				$activos[] = __( 'plugins', 'appseo-ryf' );
			}

			AppSEO_RyF_Log::anotar(
				'ajustes_guardar',
				array(
					'resumen' => $activos
						? sprintf(
							/* translators: %s: lista de permisos activos. */
							__( 'Permisos activos: %s', 'appseo-ryf' ),
							implode( ', ', $activos )
						)
						: __( 'Sin permisos de escritura', 'appseo-ryf' ),
				)
			);
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'     => self::SLUG,
					'guardado' => isset( $_POST['regenerar'] ) ? 'regenerado' : '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Pie con la atribución de autoría.
	 *
	 * @return void
	 */
	protected function pie() {
		?>
		<p class="appseo-pie">
			<?php esc_html_e( 'Desarrollado por', 'appseo-ryf' ); ?>
			<a href="https://agenciaryf.com/" target="_blank" rel="noopener noreferrer">Agencia RYF</a>
			<span class="appseo-pie-sep">·</span>
			<span class="appseo-pie-version">AppSEO RyF v<?php echo esc_html( APPSEO_RYF_VERSION ); ?></span>
		</p>
		<?php
	}

	/**
	 * Dibuja una fila de permiso con su interruptor.
	 *
	 * @param array $args Configuración de la fila.
	 * @return void
	 */
	protected function permiso( array $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'name'      => '',
				'titulo'    => '',
				'texto'     => '',
				'activo'    => false,
				'sensible'  => false,
				'dependiente' => false,
			)
		);

		$clases = array( 'appseo-permiso' );
		if ( $args['sensible'] ) {
			$clases[] = 'es-sensible';
		}
		?>
		<div class="<?php echo esc_attr( implode( ' ', $clases ) ); ?>"
			<?php echo $args['dependiente'] ? 'data-depende-de-escritura' : ''; ?>>
			<div>
				<h3><?php echo esc_html( $args['titulo'] ); ?></h3>
				<p><?php echo esc_html( $args['texto'] ); ?></p>
			</div>
			<label class="appseo-switch">
				<input type="checkbox" name="<?php echo esc_attr( $args['name'] ); ?>" value="1"
					<?php checked( (bool) $args['activo'] ); ?>
					aria-label="<?php echo esc_attr( $args['titulo'] ); ?>">
				<span class="appseo-pista"></span>
			</label>
		</div>
		<?php
	}

	/**
	 * Página principal.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = AppSEO_RyF_Settings::all();
		$actuando = AppSEO_RyF_Settings::acting_user_id();
		$aviso    = isset( $_GET['guardado'] ) ? sanitize_key( wp_unslash( $_GET['guardado'] ) ) : '';
		$lista    = is_array( $settings['plugin_allowlist'] ) ? $settings['plugin_allowlist'] : array();

		list( $estado ) = $this->estado_conexion();
		$clase_punto = empty( $settings['last_seen'] ) ? 'es-ambar' : ( AppSEO_RyF_Settings::is_read_only() ? 'es-azul' : 'es-verde' );
		?>
		<div class="wrap">
		<div class="appseo-wrap">

			<div class="appseo-hero">
				<div>
					<h1>App<span class="appseo-marca">SEO</span> RyF</h1>
					<p><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?> · v<?php echo esc_html( APPSEO_RYF_VERSION ); ?></p>
				</div>
				<span class="appseo-estado">
					<span class="appseo-punto <?php echo esc_attr( $clase_punto ); ?>"></span>
					<?php echo esc_html( $estado ); ?>
				</span>
			</div>

			<?php if ( 'regenerado' === $aviso ) : ?>
				<div class="appseo-aviso">
					<strong><?php esc_html_e( 'Credenciales regeneradas.', 'appseo-ryf' ); ?></strong>
					<?php esc_html_e( 'La conexión anterior ha dejado de funcionar: pega la nueva cadena en el panel.', 'appseo-ryf' ); ?>
				</div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<?php wp_nonce_field( self::ACTION ); ?>

				<section class="appseo-tarjeta">
					<header>
						<h2><?php esc_html_e( 'Cadena de conexión', 'appseo-ryf' ); ?></h2>
						<p><?php esc_html_e( 'Pégala en el panel de AppSEO. Contiene el secreto compartido: trátala como una contraseña.', 'appseo-ryf' ); ?></p>
					</header>
					<div class="appseo-cuerpo">
						<div class="appseo-cadena">
							<textarea id="appseo-cadena" readonly rows="3" onclick="this.select()"><?php echo esc_textarea( AppSEO_RyF_Auth::connection_string() ); ?></textarea>
							<button type="button" class="appseo-copiar" data-copiado="<?php esc_attr_e( 'Copiado', 'appseo-ryf' ); ?>">
								<?php esc_html_e( 'Copiar', 'appseo-ryf' ); ?>
							</button>
						</div>
					</div>
				</section>

				<section class="appseo-tarjeta">
					<header>
						<h2><?php esc_html_e( 'Permisos', 'appseo-ryf' ); ?></h2>
						<p><?php esc_html_e( 'Todos empiezan apagados. El primero manda sobre el resto.', 'appseo-ryf' ); ?></p>
					</header>
					<div class="appseo-cuerpo">

						<?php
						$this->permiso(
							array(
								'name'   => 'allow_writes',
								'titulo' => __( 'Cambios en el contenido', 'appseo-ryf' ),
								'texto'  => __( 'Permite crear y editar entradas, páginas y productos. Con esto apagado el panel solo puede auditar, y ningún otro permiso de abajo tiene efecto.', 'appseo-ryf' ),
								'activo' => ! AppSEO_RyF_Settings::is_read_only(),
							)
						);

						$this->permiso(
							array(
								'name'        => 'allow_publish',
								'titulo'      => __( 'Publicación directa', 'appseo-ryf' ),
								'texto'       => __( 'Deja que el panel publique sin revisión humana. Apagado, todo llega como borrador.', 'appseo-ryf' ),
								'activo'      => (bool) $settings['allow_publish'],
								'dependiente' => true,
							)
						);

						$this->permiso(
							array(
								'name'        => 'allow_price_writes',
								'titulo'      => __( 'Precios de WooCommerce', 'appseo-ryf' ),
								'texto'       => __( 'Un error en un texto se corrige sin consecuencias; uno en los precios cuesta ventas de inmediato. El stock y el SKU no se escriben nunca, ni con esto encendido.', 'appseo-ryf' ),
								'activo'      => (bool) AppSEO_RyF_Settings::get( 'allow_price_writes', 0 ),
								'sensible'    => true,
								'dependiente' => true,
							)
						);

						$this->permiso(
							array(
								'name'        => 'allow_plugin_management',
								'titulo'      => __( 'Gestión de plugins', 'appseo-ryf' ),
								'texto'       => __( 'Instalar, activar y desactivar plugins del repositorio oficial de WordPress.org. Nunca desde archivos externos, nunca borrando, y sin poder desactivarse a sí mismo.', 'appseo-ryf' ),
								'activo'      => (bool) AppSEO_RyF_Settings::get( 'allow_plugin_management', 0 ),
								'sensible'    => true,
								'dependiente' => true,
							)
						);
						?>

						<div class="appseo-campo">
							<label for="plugin_allowlist"><?php esc_html_e( 'Plugins permitidos', 'appseo-ryf' ); ?></label>
							<p class="appseo-ayuda"><?php esc_html_e( 'Slugs separados por comas. Vacío significa cualquiera del repositorio oficial.', 'appseo-ryf' ); ?></p>
							<textarea name="plugin_allowlist" id="plugin_allowlist" rows="2" placeholder="wordpress-seo, elementor, litespeed-cache"><?php echo esc_textarea( implode( ', ', $lista ) ); ?></textarea>
						</div>

						<div class="appseo-campo">
							<label for="acting_user"><?php esc_html_e( 'Autor de los cambios', 'appseo-ryf' ); ?></label>
							<p class="appseo-ayuda"><?php esc_html_e( 'Usa un usuario dedicado. Así tu historial distingue lo que hizo el panel de lo que hicisteis vosotros.', 'appseo-ryf' ); ?></p>
							<?php
							wp_dropdown_users(
								array(
									'name'              => 'acting_user',
									'id'                => 'acting_user',
									'selected'          => $actuando,
									'show_option_none'  => __( '— Ninguno (bloquea la escritura) —', 'appseo-ryf' ),
									'option_none_value' => 0,
									'capability'        => 'edit_posts',
								)
							);
							?>
						</div>

						<?php
						$this->permiso(
							array(
								'name'   => 'auto_actualizar',
								'titulo' => __( 'Actualizar el conector automáticamente', 'appseo-ryf' ),
								'texto'  => __( 'WordPress instalará las versiones nuevas del conector en cuanto se publiquen, igual que hace con cualquier otro plugin. Sin esto, las actualizaciones aparecen en la lista de plugins y se instalan a mano.', 'appseo-ryf' ),
								'activo' => (bool) AppSEO_RyF_Settings::get( 'auto_actualizar', 0 ),
							)
						);
						?>

						<?php if ( class_exists( 'WooCommerce' ) ) : ?>
						<div class="appseo-separador">
							<h2><?php esc_html_e( 'Tienda', 'appseo-ryf' ); ?></h2>
							<p><?php esc_html_e( 'Ajustes de presentación de WooCommerce. No escriben ni borran contenido: solo cambian dónde se muestra lo que ya existe.', 'appseo-ryf' ); ?></p>
						</div>

						<?php
						$this->permiso(
							array(
								'name'   => 'seo_categorias',
								'titulo' => __( 'Descripción SEO al pie de las categorías', 'appseo-ryf' ),
								'texto'  => __( 'Añade un editor «Descripción SEO» a cada categoría de producto y lo muestra debajo del listado. Admite HTML libre: encabezados, tablas o preguntas frecuentes escritas a mano. Desactivarlo oculta el bloque, nunca borra el texto.', 'appseo-ryf' ),
								'activo' => (bool) AppSEO_RyF_Settings::get( 'seo_categorias', 0 ),
							)
						);

						$this->permiso(
							array(
								'name'   => 'seo_categorias_solo_pagina_1',
								'titulo' => __( 'Ocultarla a partir de la página 2', 'appseo-ryf' ),
								'texto'  => __( 'Evita que el mismo texto aparezca en varias URLs paginadas de la misma categoría, que es lo que los buscadores leen como contenido duplicado del propio sitio.', 'appseo-ryf' ),
								'activo' => (bool) AppSEO_RyF_Settings::get( 'seo_categorias_solo_pagina_1', 1 ),
							)
						);
						?>

						<div class="appseo-campo">
							<label for="seo_categorias_css"><?php esc_html_e( 'CSS de esa sección', 'appseo-ryf' ); ?></label>
							<p class="appseo-ayuda"><?php esc_html_e( 'Se aplica solo en las páginas de categoría, dentro de .appseo-cat-seo. Va aquí y no en el plugin porque la paleta cambia en cada tienda.', 'appseo-ryf' ); ?></p>
							<textarea name="seo_categorias_css" id="seo_categorias_css" rows="8" spellcheck="false" placeholder=".appseo-cat-seo h2 { font-size: 1.5rem; }"><?php echo esc_textarea( (string) AppSEO_RyF_Settings::get( 'seo_categorias_css', '' ) ); ?></textarea>
						</div>
						<?php endif; ?>

						<div class="appseo-campo">
							<label for="meta_desc_categoria"><?php esc_html_e( 'Dónde guarda este sitio la descripción SEO', 'appseo-ryf' ); ?></label>
							<p class="appseo-ayuda"><?php esc_html_e( 'Déjalo vacío salvo que esta tienda ya tuviera su propio desarrollo a medida guardando ese texto en otro sitio. Si lo dejas mal, el panel escribirá donde tu plantilla no mira y el texto no se verá nunca.', 'appseo-ryf' ); ?></p>
							<input type="text" name="meta_desc_categoria" id="meta_desc_categoria" spellcheck="false"
								placeholder="<?php echo esc_attr( AppSEO_RyF_Categorias::META_DESC ); ?>"
								value="<?php echo esc_attr( (string) AppSEO_RyF_Settings::get( 'meta_desc_categoria', '' ) ); ?>">
						</div>

						<div class="appseo-campo">
							<label for="meta_faqs_categoria"><?php esc_html_e( 'Dónde guarda las preguntas frecuentes', 'appseo-ryf' ); ?></label>
							<p class="appseo-ayuda"><?php esc_html_e( 'Vacío significa que esta tienda no tiene preguntas frecuentes por categoría, y el panel no las tocará. Con una clave puesta, las lee y las escribe en el mismo formato que ya use la plantilla.', 'appseo-ryf' ); ?></p>
							<input type="text" name="meta_faqs_categoria" id="meta_faqs_categoria" spellcheck="false"
								placeholder="<?php esc_attr_e( 'ninguna', 'appseo-ryf' ); ?>"
								value="<?php echo esc_attr( (string) AppSEO_RyF_Settings::get( 'meta_faqs_categoria', '' ) ); ?>">
						</div>

						<div class="appseo-acciones">
							<button type="submit" class="appseo-boton"><?php esc_html_e( 'Guardar cambios', 'appseo-ryf' ); ?></button>
							<span class="appseo-guardado <?php echo '1' === $aviso ? 'se-ve' : ''; ?>"><?php esc_html_e( 'Ajustes guardados', 'appseo-ryf' ); ?></span>
						</div>
					</div>
				</section>

				<section class="appseo-tarjeta">
					<header>
						<h2><?php esc_html_e( 'Zona delicada', 'appseo-ryf' ); ?></h2>
						<p><?php esc_html_e( 'Regenerar desconecta el panel al instante. Úsalo si sospechas que la cadena se ha filtrado.', 'appseo-ryf' ); ?></p>
					</header>
					<div class="appseo-cuerpo">
						<button type="submit" name="regenerar" value="1" class="appseo-boton es-peligro"
							data-confirmar="<?php esc_attr_e( '¿Seguro? El panel dejará de tener acceso hasta que pegues la nueva cadena.', 'appseo-ryf' ); ?>">
							<?php esc_html_e( 'Regenerar credenciales', 'appseo-ryf' ); ?>
						</button>
					</div>
				</section>
			</form>

			<?php $this->pie(); ?>

		</div>
		</div>
		<?php
	}

	/**
	 * Página del registro de actividad.
	 *
	 * @return void
	 */
	public function render_registro() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$pagina  = isset( $_GET['paged'] ) ? absint( wp_unslash( $_GET['paged'] ) ) : 1;
		$filtro  = isset( $_GET['resultado'] ) ? sanitize_key( wp_unslash( $_GET['resultado'] ) ) : '';
		$datos   = AppSEO_RyF_Log::consultar( array( 'pagina' => $pagina, 'resultado' => $filtro, 'por_pagina' => 40 ) );
		$base    = admin_url( 'admin.php?page=' . self::SLUG . '-registro' );
		$conteo  = $datos['conteo'];

		list( $estado ) = $this->estado_conexion();
		$clase_punto = $this->clase_punto();
		?>
		<div class="wrap">
		<div class="appseo-wrap">

			<div class="appseo-hero">
				<div>
					<h1><?php esc_html_e( 'Registro', 'appseo-ryf' ); ?></h1>
					<p><?php esc_html_e( 'Todo lo que el panel ha hecho en este sitio', 'appseo-ryf' ); ?></p>
				</div>
				<span class="appseo-estado">
					<span class="appseo-punto <?php echo esc_attr( $clase_punto ); ?>"></span>
					<?php echo esc_html( $estado ); ?>
				</span>
			</div>

			<div class="appseo-cifras">
				<div class="appseo-cifra">
					<strong><?php echo esc_html( number_format_i18n( $datos['total'] ) ); ?></strong>
					<span><?php esc_html_e( 'operaciones', 'appseo-ryf' ); ?></span>
				</div>
				<div class="appseo-cifra es-ok">
					<strong><?php echo esc_html( number_format_i18n( $conteo['ok'] ) ); ?></strong>
					<span><?php esc_html_e( 'completadas', 'appseo-ryf' ); ?></span>
				</div>
				<div class="appseo-cifra es-bloqueado">
					<strong><?php echo esc_html( number_format_i18n( $conteo['bloqueado'] ) ); ?></strong>
					<span><?php esc_html_e( 'bloqueadas', 'appseo-ryf' ); ?></span>
				</div>
				<div class="appseo-cifra es-error">
					<strong><?php echo esc_html( number_format_i18n( $conteo['error'] ) ); ?></strong>
					<span><?php esc_html_e( 'con error', 'appseo-ryf' ); ?></span>
				</div>
			</div>

			<section class="appseo-tarjeta">
				<header>
					<h2><?php esc_html_e( 'Operaciones', 'appseo-ryf' ); ?></h2>
					<p><?php esc_html_e( 'Las más recientes primero. Se conservan las últimas 2.000.', 'appseo-ryf' ); ?></p>
				</header>

				<div class="appseo-filtros">
					<?php
					$opciones = array(
						''          => __( 'Todas', 'appseo-ryf' ),
						'ok'        => __( 'Completadas', 'appseo-ryf' ),
						'bloqueado' => __( 'Bloqueadas', 'appseo-ryf' ),
						'error'     => __( 'Con error', 'appseo-ryf' ),
					);
					foreach ( $opciones as $valor => $etiqueta ) :
						$url = $valor ? add_query_arg( 'resultado', $valor, $base ) : $base;
						?>
						<a class="appseo-filtro <?php echo $filtro === $valor ? 'esta-activo' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
							<?php echo esc_html( $etiqueta ); ?>
						</a>
					<?php endforeach; ?>
				</div>

				<?php if ( empty( $datos['entradas'] ) ) : ?>
					<div class="appseo-vacio">
						<p><?php esc_html_e( 'Todavía no hay nada registrado.', 'appseo-ryf' ); ?></p>
						<p class="appseo-vacio-nota"><?php esc_html_e( 'Aquí aparecerá cada entrada creada, cada producto editado y cada plugin instalado por el panel.', 'appseo-ryf' ); ?></p>
					</div>
				<?php else : ?>
					<table class="appseo-registro">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Cuándo', 'appseo-ryf' ); ?></th>
								<th><?php esc_html_e( 'Operación', 'appseo-ryf' ); ?></th>
								<th><?php esc_html_e( 'Detalle', 'appseo-ryf' ); ?></th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $datos['entradas'] as $fila ) : ?>
								<tr>
									<td class="appseo-cuando">
										<?php echo esc_html( mysql2date( 'j M · H:i', $fila->creado ) ); ?>
									</td>
									<td>
										<span class="appseo-accion"><?php echo esc_html( AppSEO_RyF_Log::etiqueta( $fila->accion ) ); ?></span>
										<?php if ( $fila->objeto_id ) : ?>
											<a class="appseo-objeto" href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $fila->objeto_id . '&action=edit' ) ); ?>">#<?php echo (int) $fila->objeto_id; ?></a>
										<?php endif; ?>
									</td>
									<td class="appseo-detalle"><?php echo esc_html( $fila->resumen ); ?></td>
									<td class="appseo-resultado">
										<span class="appseo-chip es-<?php echo esc_attr( $fila->resultado ); ?>">
											<?php echo esc_html( $fila->resultado ); ?>
										</span>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>

					<?php if ( $datos['paginas'] > 1 ) : ?>
						<div class="appseo-paginacion">
							<?php
							echo wp_kses_post(
								paginate_links(
									array(
										'base'      => add_query_arg( 'paged', '%#%', $filtro ? add_query_arg( 'resultado', $filtro, $base ) : $base ),
										'format'    => '',
										'current'   => $datos['pagina'],
										'total'     => $datos['paginas'],
										'prev_text' => '‹',
										'next_text' => '›',
									)
								)
							);
							?>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			</section>

			<?php $this->pie(); ?>

		</div>
		</div>
		<?php
	}

	/**
	 * Clase CSS del punto de estado.
	 *
	 * @return string
	 */
	protected function clase_punto() {
		$settings = AppSEO_RyF_Settings::all();
		if ( empty( $settings['last_seen'] ) ) {
			return 'es-ambar';
		}
		return AppSEO_RyF_Settings::is_read_only() ? 'es-azul' : 'es-verde';
	}

	/**
	 * Página de alcance y estado.
	 *
	 * @return void
	 */
	public function render_actividad() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = AppSEO_RyF_Settings::all();
		list( $estado ) = $this->estado_conexion();
		$clase_punto = empty( $settings['last_seen'] ) ? 'es-ambar' : ( AppSEO_RyF_Settings::is_read_only() ? 'es-azul' : 'es-verde' );
		?>
		<div class="wrap">
		<div class="appseo-wrap">

			<div class="appseo-hero">
				<div>
					<h1><?php esc_html_e( 'Actividad', 'appseo-ryf' ); ?></h1>
					<p><?php esc_html_e( 'Qué ha hecho el panel y qué tiene permitido hacer', 'appseo-ryf' ); ?></p>
				</div>
				<span class="appseo-estado">
					<span class="appseo-punto <?php echo esc_attr( $clase_punto ); ?>"></span>
					<?php echo esc_html( $estado ); ?>
				</span>
			</div>

			<section class="appseo-tarjeta">
				<header><h2><?php esc_html_e( 'Conexión', 'appseo-ryf' ); ?></h2></header>
				<div class="appseo-cuerpo">
					<table class="appseo-datos">
						<tbody>
							<tr>
								<td><?php esc_html_e( 'Última conexión del panel', 'appseo-ryf' ); ?></td>
								<td><?php echo $settings['last_seen'] ? esc_html( wp_date( 'j M Y · H:i', (int) $settings['last_seen'] ) ) : esc_html__( 'nunca', 'appseo-ryf' ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Dirección IP', 'appseo-ryf' ); ?></td>
								<td><?php echo esc_html( $settings['last_ip'] ? $settings['last_ip'] : '—' ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Cambios en el contenido', 'appseo-ryf' ); ?></td>
								<td><?php echo AppSEO_RyF_Settings::is_read_only() ? esc_html__( 'bloqueados', 'appseo-ryf' ) : esc_html__( 'permitidos', 'appseo-ryf' ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Publicación directa', 'appseo-ryf' ); ?></td>
								<td><?php echo AppSEO_RyF_Settings::get( 'allow_publish', 0 ) ? esc_html__( 'permitida', 'appseo-ryf' ) : esc_html__( 'bloqueada', 'appseo-ryf' ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Precios de WooCommerce', 'appseo-ryf' ); ?></td>
								<td><?php echo AppSEO_RyF_Settings::get( 'allow_price_writes', 0 ) ? esc_html__( 'permitidos', 'appseo-ryf' ) : esc_html__( 'bloqueados', 'appseo-ryf' ); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e( 'Gestión de plugins', 'appseo-ryf' ); ?></td>
								<td><?php echo AppSEO_RyF_Settings::get( 'allow_plugin_management', 0 ) ? esc_html__( 'permitida', 'appseo-ryf' ) : esc_html__( 'bloqueada', 'appseo-ryf' ); ?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</section>

			<section class="appseo-tarjeta">
				<header>
					<h2><?php esc_html_e( 'Alcance del conector', 'appseo-ryf' ); ?></h2>
					<p><?php esc_html_e( 'Los límites están en el código, no en la configuración.', 'appseo-ryf' ); ?></p>
				</header>
				<div class="appseo-cuerpo">
					<div class="appseo-capacidades">
						<div class="es-si">
							<h3><?php esc_html_e( 'Puede', 'appseo-ryf' ); ?></h3>
							<ul>
								<li><?php esc_html_e( 'Leer contenido y calcular auditorías', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Crear y editar entradas, páginas y productos', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Subir imágenes a la biblioteca', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Escribir metadatos de Yoast, Rank Math y Elementor', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Instalar y activar plugins oficiales, si lo autorizas', 'appseo-ryf' ); ?></li>
							</ul>
						</div>
						<div class="es-no">
							<h3><?php esc_html_e( 'No puede', 'appseo-ryf' ); ?></h3>
							<ul>
								<li><?php esc_html_e( 'Ejecutar código PHP', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Leer ni escribir archivos del servidor', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Borrar plugins ni temas', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Escribir stock ni SKU', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Acceder a usuarios, pedidos o datos de clientes', 'appseo-ryf' ); ?></li>
								<li><?php esc_html_e( 'Desactivarse a sí mismo', 'appseo-ryf' ); ?></li>
							</ul>
						</div>
					</div>
				</div>
			</section>

			<?php $this->pie(); ?>

		</div>
		</div>
		<?php
	}
}
