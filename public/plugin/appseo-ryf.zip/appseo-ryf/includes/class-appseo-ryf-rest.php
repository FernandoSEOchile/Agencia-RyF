<?php
/**
 * Endpoints REST del conector.
 *
 * Cinco rutas, ninguna de ellas capaz de ejecutar código: salud, auditoría,
 * lectura de contenido, escritura de contenido y subida de medios.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registro de rutas.
 */
class AppSEO_RyF_REST {

	/**
	 * Engancha el registro de rutas.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	/**
	 * Define las rutas.
	 *
	 * @return void
	 */
	public function routes() {
		$auth = array( $this, 'authorize' );

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/health',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'health' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/audit',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'audit' ),
				'permission_callback' => $auth,
				'args'                => array(
					'limit'          => array(
						'type'              => 'integer',
						'default'           => AppSEO_RyF_Audit::DEFAULT_LIMIT,
						'sanitize_callback' => 'absint',
					),
					'modified_after' => array(
						'type'              => 'string',
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'include_links'  => array(
						'type'    => 'boolean',
						'default' => true,
					),
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/content/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_content' ),
				'permission_callback' => $auth,
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/content',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'write_content' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/theme',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_theme' ),
				'permission_callback' => $auth,
				'args'                => array(
					'url' => array( 'type' => 'string', 'default' => '' ),
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/css',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_css' ),
					'permission_callback' => $auth,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'write_css' ),
					'permission_callback' => $auth,
					'args'                => array(
						'css'  => array( 'type' => 'string', 'required' => true ),
						'modo' => array(
							'type'    => 'string',
							'default' => 'reemplazar',
							'enum'    => array( 'reemplazar', 'anexar' ),
						),
					),
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/log',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'read_log' ),
				'permission_callback' => $auth,
				'args'                => array(
					'pagina'     => array( 'type' => 'integer', 'default' => 1, 'sanitize_callback' => 'absint' ),
					'por_pagina' => array( 'type' => 'integer', 'default' => 50, 'sanitize_callback' => 'absint' ),
					'resultado'  => array( 'type' => 'string', 'default' => '' ),
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/plugins',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_plugins' ),
					'permission_callback' => $auth,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'manage_plugin' ),
					'permission_callback' => $auth,
					'args'                => array(
						'accion'  => array(
							'type'     => 'string',
							'required' => true,
							'enum'     => array( 'instalar', 'activar', 'desactivar' ),
						),
						'slug'    => array( 'type' => 'string', 'default' => '' ),
						'archivo' => array( 'type' => 'string', 'default' => '' ),
					),
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/products',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'list_products' ),
					'permission_callback' => $auth,
					'args'                => array(
						'limit'  => array( 'type' => 'integer', 'default' => 100, 'sanitize_callback' => 'absint' ),
						'pagina' => array( 'type' => 'integer', 'default' => 1, 'sanitize_callback' => 'absint' ),
						'estado' => array( 'type' => 'string', 'default' => '' ),
					),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'write_product' ),
					'permission_callback' => $auth,
				),
			)
		);

		// Categorías de producto: descripción SEO al pie.
		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/terms',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_terms_appseo' ),
					'permission_callback' => $auth,
					'args'                => array(
						'taxonomia' => array( 'type' => 'string', 'default' => 'product_cat' ),
						'con_texto' => array( 'type' => 'boolean', 'default' => false ),
					),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'set_term_appseo' ),
					'permission_callback' => $auth,
				),
			)
		);

		// Ajustes de presentación. A propósito NO expone credenciales ni
		// permisos: quién puede escribir en un sitio se decide en el propio
		// WordPress, no desde el panel que va a escribir.
		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/ajustes',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_ajustes' ),
					'permission_callback' => $auth,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'set_ajustes' ),
					'permission_callback' => $auth,
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/products/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_product' ),
				'permission_callback' => $auth,
				'args'                => array(
					'id' => array( 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ),
				),
			)
		);

		register_rest_route(
			APPSEO_RYF_NAMESPACE,
			'/media',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'write_media' ),
				'permission_callback' => $auth,
				'args'                => array(
					'nombre'   => array(
						'type'     => 'string',
						'required' => true,
					),
					'contenido' => array(
						'type'     => 'string',
						'required' => true,
					),
					'alt'      => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
	}

	/**
	 * Comprueba la firma de la petición.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return true|WP_Error
	 */
	public function authorize( WP_REST_Request $request ) {
		return AppSEO_RyF_Auth::verify( $request );
	}

	/**
	 * Estado del conector y del sitio.
	 *
	 * @return WP_REST_Response
	 */
	public function health() {
		$settings = AppSEO_RyF_Settings::all();

		return rest_ensure_response(
			array(
				'ok'            => true,
				'conector'      => APPSEO_RYF_VERSION,
				'wordpress'     => get_bloginfo( 'version' ),
				'php'           => PHP_VERSION,
				'sitio'         => home_url(),
				'solo_lectura'  => AppSEO_RyF_Settings::is_read_only(),
				'permite_publicar' => (bool) AppSEO_RyF_Settings::get( 'allow_publish', 0 ),
				'usuario_activo'  => AppSEO_RyF_Settings::acting_user_id(),
				'ultima_conexion' => (int) $settings['last_seen'],
			)
		);
	}

	/**
	 * Auditoría completa del contenido.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response
	 */
	public function audit( WP_REST_Request $request ) {
		$auditoria = new AppSEO_RyF_Audit();

		return rest_ensure_response(
			$auditoria->collect(
				array(
					'limit'          => $request->get_param( 'limit' ),
					'modified_after' => $request->get_param( 'modified_after' ),
					'include_links'  => (bool) $request->get_param( 'include_links' ),
				)
			)
		);
	}

	/**
	 * Devuelve una pieza concreta.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_content( WP_REST_Request $request ) {
		$contenido = new AppSEO_RyF_Content();
		$resultado = $contenido->get( $request->get_param( 'id' ) );

		return is_wp_error( $resultado ) ? $resultado : rest_ensure_response( $resultado );
	}

	/**
	 * Crea o actualiza una pieza.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function write_content( WP_REST_Request $request ) {
		$contenido = new AppSEO_RyF_Content();
		$resultado = $contenido->upsert( (array) $request->get_json_params() );

		return is_wp_error( $resultado ) ? $resultado : rest_ensure_response( $resultado );
	}

	/**
	 * Huella del tema activo, para que el panel no estudie cada cliente a mano.
	 *
	 * @return WP_REST_Response
	 */
	public function get_theme( WP_REST_Request $request ) {
		$tema = new AppSEO_RyF_Tema();
		return rest_ensure_response( $tema->huella( (string) $request->get_param( 'url' ) ) );
	}

	/**
	 * Devuelve el CSS adicional del sitio.
	 *
	 * @return WP_REST_Response
	 */
	public function get_css() {
		$estilos = new AppSEO_RyF_Estilos();
		return rest_ensure_response( $estilos->obtener() );
	}

	/**
	 * Escribe el CSS adicional del sitio.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function write_css( WP_REST_Request $request ) {
		$estilos = new AppSEO_RyF_Estilos();
		$r       = $estilos->guardar( $request->get_param( 'css' ), $request->get_param( 'modo' ) );

		return is_wp_error( $r ) ? $r : rest_ensure_response( $r );
	}

	/**
	 * Registro de actividad, con diagnóstico de la propia tabla.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response
	 */
	public function read_log( WP_REST_Request $request ) {
		$datos = AppSEO_RyF_Log::consultar(
			array(
				'pagina'     => $request->get_param( 'pagina' ),
				'por_pagina' => $request->get_param( 'por_pagina' ),
				'resultado'  => $request->get_param( 'resultado' ),
			)
		);

		if ( '1' === (string) $request->get_param( 'probar' ) ) {
			$datos['prueba'] = AppSEO_RyF_Log::probar();
		}

		$datos['diagnostico'] = AppSEO_RyF_Log::diagnostico();

		return rest_ensure_response( $datos );
	}

	/**
	 * Listado de productos de WooCommerce.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function list_products( WP_REST_Request $request ) {
		$woo = new AppSEO_RyF_Woo();
		$r   = $woo->listar(
			array(
				'limit'  => $request->get_param( 'limit' ),
				'pagina' => $request->get_param( 'pagina' ),
				'estado' => $request->get_param( 'estado' ),
			)
		);
		return is_wp_error( $r ) ? $r : rest_ensure_response( $r );
	}

	/**
	 * Ficha completa de un producto.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_product( WP_REST_Request $request ) {
		$woo = new AppSEO_RyF_Woo();
		$r   = $woo->obtener( $request->get_param( 'id' ) );
		return is_wp_error( $r ) ? $r : rest_ensure_response( $r );
	}

	/**
	 * Lista los términos con el estado de su descripción SEO.
	 *
	 * Por defecto devuelve solo el tamaño del texto, no el texto: un catálogo
	 * de cien categorías con sus descripciones completas es una respuesta
	 * enorme que casi nunca hace falta entera.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_terms_appseo( WP_REST_Request $request ) {
		$taxonomia = (string) $request->get_param( 'taxonomia' );

		if ( ! taxonomy_exists( $taxonomia ) ) {
			return new WP_Error(
				'appseo_taxonomia_desconocida',
				__( 'Esa taxonomía no existe en este sitio.', 'appseo-ryf' ),
				array( 'status' => 400 )
			);
		}

		$terminos = get_terms(
			array(
				'taxonomy'   => $taxonomia,
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terminos ) ) {
			return $terminos;
		}

		$con_texto = (bool) $request->get_param( 'con_texto' );
		$salida    = array();

		foreach ( $terminos as $t ) {
			$seo = (string) get_term_meta( $t->term_id, AppSEO_RyF_Categorias::META_DESC, true );

			$fila = array(
				'id'         => $t->term_id,
				'nombre'     => $t->name,
				'slug'       => $t->slug,
				'padre'      => $t->parent,
				'productos'  => $t->count,
				'url'        => get_term_link( $t ),
				'desc_nativa' => strlen( (string) $t->description ),
				'seo_bytes'  => strlen( $seo ),
				'faq_bytes'  => strlen( (string) get_term_meta( $t->term_id, 'category_faqs', true ) ),
			);

			if ( $con_texto ) {
				$fila['seo'] = htmlspecialchars_decode( $seo );
			}

			$salida[] = $fila;
		}

		return rest_ensure_response(
			array(
				'taxonomia' => $taxonomia,
				'total'     => count( $salida ),
				'terminos'  => $salida,
			)
		);
	}

	/**
	 * Crea una categoría o escribe la descripción SEO de una existente.
	 *
	 * Las dos cosas van por la misma puerta —con `id` escribe, sin `id` crea—
	 * porque el panel casi nunca sabe de antemano si la sección de la
	 * arquitectura ya existe en el sitio. Obligarle a preguntar primero
	 * añadiría una llamada a cada alta sin evitar la carrera.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function set_term_appseo( WP_REST_Request $request ) {
		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return new WP_Error(
				'appseo_read_only',
				__( 'Este sitio está en modo solo lectura.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$cuerpo    = (array) $request->get_json_params();
		$term_id   = isset( $cuerpo['id'] ) ? (int) $cuerpo['id'] : 0;
		$taxonomia = isset( $cuerpo['taxonomia'] ) ? (string) $cuerpo['taxonomia'] : 'product_cat';

		if ( ! taxonomy_exists( $taxonomia ) ) {
			return new WP_Error(
				'appseo_taxonomia_desconocida',
				__( 'Esa taxonomía no existe en este sitio.', 'appseo-ryf' ),
				array( 'status' => 400 )
			);
		}

		$creado = false;

		if ( $term_id ) {
			$termino = get_term( $term_id, $taxonomia );

			if ( ! $termino || is_wp_error( $termino ) ) {
				return new WP_Error(
					'appseo_termino_no_encontrado',
					__( 'No existe ese término.', 'appseo-ryf' ),
					array( 'status' => 404 )
				);
			}

			if ( ! array_key_exists( 'seo', $cuerpo ) ) {
				return new WP_Error(
					'appseo_sin_cambios',
					__( 'Falta el campo «seo».', 'appseo-ryf' ),
					array( 'status' => 400 )
				);
			}
		} else {
			// Se exige el nombre en vez de deducirlo del slug: el nombre es lo
			// que ve el visitante en el menú y en las migas, y una URL no da
			// para reconstruirlo con acentos ni mayúsculas.
			$nombre = isset( $cuerpo['nombre'] ) ? sanitize_text_field( (string) $cuerpo['nombre'] ) : '';

			if ( '' === $nombre ) {
				return new WP_Error(
					'appseo_falta_nombre',
					__( 'Para crear una categoría hace falta su nombre.', 'appseo-ryf' ),
					array( 'status' => 400 )
				);
			}

			$padre = isset( $cuerpo['padre'] ) ? (int) $cuerpo['padre'] : 0;

			if ( $padre ) {
				$madre = get_term( $padre, $taxonomia );
				if ( ! $madre || is_wp_error( $madre ) ) {
					return new WP_Error(
						'appseo_padre_no_encontrado',
						__( 'La categoría madre indicada no existe.', 'appseo-ryf' ),
						array( 'status' => 404 )
					);
				}
			}

			$alta = wp_insert_term(
				$nombre,
				$taxonomia,
				array(
					'slug'        => isset( $cuerpo['slug'] ) ? sanitize_title( (string) $cuerpo['slug'] ) : '',
					'parent'      => $padre,
					'description' => isset( $cuerpo['descripcion'] ) ? wp_kses_post( (string) $cuerpo['descripcion'] ) : '',
				)
			);

			if ( is_wp_error( $alta ) ) {
				// El choque con una categoría existente es el fallo habitual, y
				// se contesta con su id: quien llamó quería que la sección
				// existiera, y ya existe. Sin el id habría que buscarla otra vez.
				if ( 'term_exists' === $alta->get_error_code() ) {
					return new WP_Error(
						'appseo_termino_repetido',
						sprintf(
							/* translators: 1: nombre de la categoría, 2: id existente. */
							__( 'Ya existe la categoría «%1$s», con el id %2$d. Escribe sobre ella en vez de crearla.', 'appseo-ryf' ),
							$nombre,
							(int) $alta->get_error_data()
						),
						array( 'status' => 409 )
					);
				}
				return $alta;
			}

			$term_id = (int) $alta['term_id'];
			$termino = get_term( $term_id, $taxonomia );
			$creado  = true;
		}

		$anterior = htmlspecialchars_decode( (string) get_term_meta( $term_id, AppSEO_RyF_Categorias::META_DESC, true ) );
		$nuevo    = $anterior;

		if ( array_key_exists( 'seo', $cuerpo ) ) {
			$nuevo = wp_kses_post( (string) $cuerpo['seo'] );

			if ( '' === trim( wp_strip_all_tags( $nuevo ) ) ) {
				delete_term_meta( $term_id, AppSEO_RyF_Categorias::META_DESC );
			} else {
				update_term_meta( $term_id, AppSEO_RyF_Categorias::META_DESC, $nuevo );
			}
		}

		AppSEO_RyF_Log::anotar(
			$creado ? 'categoria_crear' : 'categoria_seo',
			array(
				'tipo'    => $taxonomia,
				'id'      => $term_id,
				'resumen' => $creado
					? sprintf(
						/* translators: 1: nombre de la categoría, 2: bytes de descripción. */
						__( '%1$s · categoría creada con %2$s bytes de descripción', 'appseo-ryf' ),
						$termino->name,
						number_format_i18n( strlen( $nuevo ) )
					)
					: sprintf(
						/* translators: 1: nombre de la categoría, 2: bytes antes, 3: bytes después. */
						__( '%1$s · descripción SEO de %2$s a %3$s bytes', 'appseo-ryf' ),
						$termino->name,
						number_format_i18n( strlen( $anterior ) ),
						number_format_i18n( strlen( $nuevo ) )
					),
			)
		);

		$url = get_term_link( $termino );

		return rest_ensure_response(
			array(
				'ok'       => true,
				'id'       => $term_id,
				'creado'   => $creado,
				'nombre'   => $termino->name,
				'slug'     => $termino->slug,
				'padre'    => (int) $termino->parent,
				'url'      => is_wp_error( $url ) ? '' : $url,
				'editar'   => admin_url( 'term.php?taxonomy=' . rawurlencode( $taxonomia ) . '&tag_ID=' . $term_id ),
				'bytes'    => strlen( $nuevo ),
				'anterior' => $creado ? null : $anterior,
			)
		);
	}

	/**
	 * Ajustes de presentación que el panel puede consultar.
	 *
	 * @return WP_REST_Response
	 */
	public function get_ajustes() {
		return rest_ensure_response(
			array(
				'seo_categorias'               => (int) AppSEO_RyF_Settings::get( 'seo_categorias', 0 ),
				'seo_categorias_solo_pagina_1' => (int) AppSEO_RyF_Settings::get( 'seo_categorias_solo_pagina_1', 1 ),
				'seo_categorias_css'           => (string) AppSEO_RyF_Settings::get( 'seo_categorias_css', '' ),
				'fragmento_activo'             => function_exists( 'dl_mostrar_desc_seo_cat' ),
				'woocommerce'                  => class_exists( 'WooCommerce' ),
			)
		);
	}

	/**
	 * Escribe los ajustes de presentación.
	 *
	 * Solo se aceptan las claves de esta lista. Cualquier otra cosa que llegue
	 * en el cuerpo se ignora en silencio: un endpoint de ajustes que acepte
	 * claves arbitrarias acabaría siendo la vía para desactivar los propios
	 * límites del conector.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function set_ajustes( WP_REST_Request $request ) {
		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return new WP_Error(
				'appseo_read_only',
				__( 'Este sitio está en modo solo lectura.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$cuerpo   = (array) $request->get_json_params();
		$anterior = array(
			'seo_categorias'               => (int) AppSEO_RyF_Settings::get( 'seo_categorias', 0 ),
			'seo_categorias_solo_pagina_1' => (int) AppSEO_RyF_Settings::get( 'seo_categorias_solo_pagina_1', 1 ),
			'seo_categorias_css'           => (string) AppSEO_RyF_Settings::get( 'seo_categorias_css', '' ),
		);

		$cambios = array();

		foreach ( array( 'seo_categorias', 'seo_categorias_solo_pagina_1' ) as $clave ) {
			if ( array_key_exists( $clave, $cuerpo ) ) {
				$cambios[ $clave ] = $cuerpo[ $clave ] ? 1 : 0;
			}
		}

		if ( array_key_exists( 'seo_categorias_css', $cuerpo ) ) {
			$css = (string) $cuerpo['seo_categorias_css'];

			if ( strlen( $css ) > 200000 ) {
				return new WP_Error(
					'appseo_css_grande',
					__( 'El CSS supera el máximo permitido.', 'appseo-ryf' ),
					array( 'status' => 413 )
				);
			}

			$cambios['seo_categorias_css'] = AppSEO_RyF_Categorias::sanear_css( $css );
		}

		if ( empty( $cambios ) ) {
			return new WP_Error(
				'appseo_sin_cambios',
				__( 'No llegó ninguna clave reconocida.', 'appseo-ryf' ),
				array( 'status' => 400 )
			);
		}

		AppSEO_RyF_Settings::update( $cambios );

		AppSEO_RyF_Log::anotar(
			'ajustes',
			array(
				'resumen' => sprintf(
					/* translators: %s: lista de claves modificadas. */
					__( 'Ajustes de presentación actualizados: %s', 'appseo-ryf' ),
					implode( ', ', array_keys( $cambios ) )
				),
			)
		);

		return rest_ensure_response(
			array(
				'ok'        => true,
				'cambiados' => array_keys( $cambios ),
				'anterior'  => $anterior,
			)
		);
	}

	/**
	 * Crea o actualiza un producto en sus campos editoriales.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function write_product( WP_REST_Request $request ) {
		$woo = new AppSEO_RyF_Woo();
		$r   = $woo->guardar( (array) $request->get_json_params() );
		return is_wp_error( $r ) ? $r : rest_ensure_response( $r );
	}

	/**
	 * Inventario de plugins instalados.
	 *
	 * @return WP_REST_Response
	 */
	public function list_plugins() {
		$plugins = new AppSEO_RyF_Plugins();
		return rest_ensure_response( $plugins->listar() );
	}

	/**
	 * Instala, activa o desactiva un plugin.
	 *
	 * Nunca borra: la eliminación queda como tarea manual del administrador.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function manage_plugin( WP_REST_Request $request ) {
		$plugins = new AppSEO_RyF_Plugins();
		$accion  = $request->get_param( 'accion' );

		if ( 'instalar' === $accion ) {
			$slug = (string) $request->get_param( 'slug' );
			if ( '' === $slug ) {
				return new WP_Error(
					'appseo_falta_slug',
					__( 'Para instalar hace falta el slug del plugin en WordPress.org.', 'appseo-ryf' ),
					array( 'status' => 400 )
				);
			}
			$resultado = $plugins->instalar( $slug );
		} else {
			$archivo = (string) $request->get_param( 'archivo' );
			if ( '' === $archivo ) {
				return new WP_Error(
					'appseo_falta_archivo',
					__( 'Hace falta la ruta del plugin, por ejemplo wordpress-seo/wp-seo.php.', 'appseo-ryf' ),
					array( 'status' => 400 )
				);
			}
			$resultado = ( 'activar' === $accion )
				? $plugins->activar( $archivo )
				: $plugins->desactivar( $archivo );
		}

		return is_wp_error( $resultado ) ? $resultado : rest_ensure_response( $resultado );
	}

	/**
	 * Sube un archivo codificado en base64.
	 *
	 * @param WP_REST_Request $request Petición.
	 * @return WP_REST_Response|WP_Error
	 */
	public function write_media( WP_REST_Request $request ) {
		$crudo = base64_decode( $request->get_param( 'contenido' ), true );

		if ( false === $crudo || '' === $crudo ) {
			return new WP_Error(
				'appseo_base64_invalido',
				__( 'El contenido del archivo no es base64 válido.', 'appseo-ryf' ),
				array( 'status' => 400 )
			);
		}

		$limite = wp_max_upload_size();
		if ( $limite && strlen( $crudo ) > $limite ) {
			return new WP_Error(
				'appseo_archivo_grande',
				__( 'El archivo supera el tamaño máximo de subida del servidor.', 'appseo-ryf' ),
				array( 'status' => 413 )
			);
		}

		$contenido = new AppSEO_RyF_Content();
		$resultado = $contenido->upload_media(
			$request->get_param( 'nombre' ),
			$crudo,
			(string) $request->get_param( 'alt' )
		);

		return is_wp_error( $resultado ) ? $resultado : rest_ensure_response( $resultado );
	}
}
