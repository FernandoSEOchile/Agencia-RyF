<?php
/**
 * Productos de WooCommerce.
 *
 * Lee todo lo que hace falta para auditar un catálogo, pero **no escribe precio,
 * stock ni SKU**. Esa frontera es deliberada: un error en un texto se corrige y
 * no ha pasado nada; un error escribiendo precios o inventario en el catálogo de
 * un cliente le cuesta ventas reales en minutos, multiplicado por cada sitio
 * conectado. Si algún día hace falta, irá detrás de su propio interruptor.
 *
 * Las escrituras pasan siempre por las clases CRUD de WooCommerce, nunca por
 * `update_post_meta` directo: es lo que mantiene sincronizadas las tablas de
 * búsqueda (`wp_wc_product_meta_lookup`) y las cachés del catálogo.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Operaciones sobre productos.
 */
class AppSEO_RyF_Woo {

	/**
	 * Campos editoriales que siempre se aceptan.
	 *
	 * Es una lista blanca, no una lista negra. Una lista de campos prohibidos
	 * deja huecos por cada sinónimo que a nadie se le ocurrió incluir, y el
	 * campo omitido se ignora en silencio: el panel cree que el cambio se
	 * aplicó cuando no fue así. Con lista blanca, lo desconocido se rechaza.
	 */
	const CAMPOS_PERMITIDOS = array(
		'id',
		'nombre',
		'slug',
		'descripcion',
		'descripcion_corta',
		'estado',
		'categorias',
		'etiquetas',
		'imagen',
		'galeria_ids',
		'meta',
	);

	/** Campos que solo se aceptan con el interruptor de precios activado. */
	const CAMPOS_PRECIO = array( 'precio_regular', 'precio_oferta' );

	/**
	 * Comprueba que WooCommerce está disponible.
	 *
	 * @return true|WP_Error
	 */
	protected function disponible() {
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_product' ) ) {
			return new WP_Error(
				'appseo_sin_woocommerce',
				__( 'WooCommerce no está activo en este sitio.', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}
		return true;
	}

	/**
	 * Listado de productos con los datos necesarios para auditar.
	 *
	 * @param array $args {
	 *     @type int    $limit  Máximo de productos.
	 *     @type int    $pagina Página, empezando en 1.
	 *     @type string $estado Estado de publicación.
	 * }
	 * @return array|WP_Error
	 */
	public function listar( array $args = array() ) {
		$listo = $this->disponible();
		if ( is_wp_error( $listo ) ) {
			return $listo;
		}

		$limit  = max( 1, min( 500, (int) ( $args['limit'] ?? 100 ) ) );
		$pagina = max( 1, (int) ( $args['pagina'] ?? 1 ) );

		$consulta = array(
			'limit'    => $limit,
			'page'     => $pagina,
			'paginate' => true,
			'status'   => ! empty( $args['estado'] ) ? sanitize_key( $args['estado'] ) : array( 'publish', 'draft', 'pending', 'private' ),
			'orderby'  => 'date',
			'order'    => 'DESC',
		);

		$resultado = wc_get_products( $consulta );

		$productos = array();
		foreach ( $resultado->products as $producto ) {
			$productos[] = $this->resumen( $producto );
		}

		return array(
			'productos'  => $productos,
			'total'      => (int) $resultado->total,
			'paginas'    => (int) $resultado->max_num_pages,
			'pagina'     => $pagina,
			'moneda'     => get_woocommerce_currency(),
			'woocommerce'=> defined( 'WC_VERSION' ) ? WC_VERSION : '',
		);
	}

	/**
	 * Ficha resumida de un producto, pensada para auditoría.
	 *
	 * @param WC_Product $p Producto.
	 * @return array
	 */
	protected function resumen( $p ) {
		$descripcion = (string) $p->get_description();
		$corta       = (string) $p->get_short_description();

		$categorias = array();
		foreach ( $p->get_category_ids() as $term_id ) {
			$term = get_term( $term_id, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				$categorias[] = $term->name;
			}
		}

		$auditoria = new AppSEO_RyF_Audit();

		return array(
			'id'               => $p->get_id(),
			'nombre'           => $p->get_name(),
			'slug'             => $p->get_slug(),
			'url'              => get_permalink( $p->get_id() ),
			'estado'           => $p->get_status(),
			'tipo'             => $p->get_type(),
			'sku'              => $p->get_sku(),
			'precio'           => $p->get_price(),
			'precio_regular'   => $p->get_regular_price(),
			'precio_oferta'    => $p->get_sale_price(),
			'stock_estado'     => $p->get_stock_status(),
			'stock_cantidad'   => $p->get_stock_quantity(),
			'visibilidad'      => $p->get_catalog_visibility(),
			'categorias'       => $categorias,
			'imagen'           => (int) $p->get_image_id(),
			'galeria'          => count( $p->get_gallery_image_ids() ),
			'palabras_desc'    => $this->contar_palabras( wp_strip_all_tags( $descripcion ) ),
			'palabras_corta'   => $this->contar_palabras( wp_strip_all_tags( $corta ) ),
			'seo'              => $this->seo_meta( $p->get_id() ),
			'marcadores'       => $this->detectar_relleno( wp_strip_all_tags( $descripcion . ' ' . $corta ) ),
			'modificado'       => $p->get_date_modified() ? $p->get_date_modified()->date( 'Y-m-d' ) : '',
		);
	}

	/**
	 * Cuenta palabras respetando UTF-8.
	 *
	 * @param string $texto Texto plano.
	 * @return int
	 */
	protected function contar_palabras( $texto ) {
		$texto = trim( preg_replace( '/\s+/u', ' ', $texto ) );
		return ( '' === $texto ) ? 0 : count( preg_split( '/\s+/u', $texto ) );
	}

	/**
	 * Metadatos SEO del producto.
	 *
	 * @param int $id ID.
	 * @return array
	 */
	protected function seo_meta( $id ) {
		$focus = get_post_meta( $id, '_yoast_wpseo_focuskw', true );
		$desc  = get_post_meta( $id, '_yoast_wpseo_metadesc', true );

		if ( '' === $focus ) {
			$focus = get_post_meta( $id, 'rank_math_focus_keyword', true );
		}
		if ( '' === $desc ) {
			$desc = get_post_meta( $id, 'rank_math_description', true );
		}

		return array(
			'keyword'  => is_string( $focus ) ? $focus : '',
			'metadesc' => is_string( $desc ) ? $desc : '',
		);
	}

	/**
	 * Detecta texto de relleno en la ficha.
	 *
	 * @param string $texto Texto plano.
	 * @return array
	 */
	protected function detectar_relleno( $texto ) {
		$agujas = apply_filters(
			'appseo_ryf_placeholder_needles',
			array( 'lorem ipsum', 'dolor sit amet', 'consectetur adipiscing', 'texto de ejemplo' )
		);

		$bajo  = function_exists( 'mb_strtolower' ) ? mb_strtolower( $texto, 'UTF-8' ) : strtolower( $texto );
		$halla = array();

		foreach ( $agujas as $aguja ) {
			if ( false !== strpos( $bajo, $aguja ) ) {
				$halla[] = $aguja;
			}
		}

		return $halla;
	}

	/**
	 * Ficha completa de un producto.
	 *
	 * @param int $id ID.
	 * @return array|WP_Error
	 */
	public function obtener( $id ) {
		$listo = $this->disponible();
		if ( is_wp_error( $listo ) ) {
			return $listo;
		}

		$p = wc_get_product( (int) $id );
		if ( ! $p ) {
			return new WP_Error(
				'appseo_producto_no_encontrado',
				__( 'No existe un producto con ese identificador.', 'appseo-ryf' ),
				array( 'status' => 404 )
			);
		}

		$datos = $this->resumen( $p );
		$datos['descripcion']       = $p->get_description();
		$datos['descripcion_corta'] = $p->get_short_description();
		$datos['galeria_ids']       = $p->get_gallery_image_ids();
		$datos['etiquetas']         = wp_get_post_terms( $p->get_id(), 'product_tag', array( 'fields' => 'names' ) );

		return $datos;
	}

	/**
	 * Crea o actualiza un producto, solo en sus campos editoriales.
	 *
	 * @param array $data Datos entrantes.
	 * @return array|WP_Error
	 */
	public function guardar( array $data ) {
		$listo = $this->disponible();
		if ( is_wp_error( $listo ) ) {
			return $listo;
		}

		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return new WP_Error(
				'appseo_read_only',
				__( 'Este sitio está en modo solo lectura.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$autor = AppSEO_RyF_Settings::acting_user_id();
		if ( ! $autor ) {
			return new WP_Error(
				'appseo_no_acting_user',
				__( 'No hay un usuario válido configurado para atribuir los cambios.', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}

		$precios_activos = (bool) AppSEO_RyF_Settings::get( 'allow_price_writes', 0 );
		$aceptados       = self::CAMPOS_PERMITIDOS;
		if ( $precios_activos ) {
			$aceptados = array_merge( $aceptados, self::CAMPOS_PRECIO );
		}

		$desconocidos = array_diff( array_keys( $data ), $aceptados );

		if ( ! empty( $desconocidos ) ) {
			$de_precio = array_intersect( $desconocidos, self::CAMPOS_PRECIO );

			if ( ! empty( $de_precio ) && ! $precios_activos ) {
				return new WP_Error(
					'appseo_precios_bloqueados',
					sprintf(
						/* translators: %s: lista de campos rechazados. */
						__( 'La escritura de precios está desactivada en este sitio. Actívala en AppSEO → Conexión si quieres permitirla. Campos rechazados: %s', 'appseo-ryf' ),
						implode( ', ', $de_precio )
					),
					array( 'status' => 403 )
				);
			}

			return new WP_Error(
				'appseo_campo_desconocido',
				sprintf(
					/* translators: 1: campos rechazados, 2: campos aceptados. */
					__( 'Campos no reconocidos: %1$s. Este conector nunca escribe stock ni SKU. Acepta: %2$s', 'appseo-ryf' ),
					implode( ', ', $desconocidos ),
					implode( ', ', $aceptados )
				),
				array( 'status' => 400 )
			);
		}

		$id = isset( $data['id'] ) ? (int) $data['id'] : 0;

		if ( $id ) {
			$producto = wc_get_product( $id );
			if ( ! $producto ) {
				return new WP_Error(
					'appseo_producto_no_encontrado',
					__( 'No existe un producto con ese identificador.', 'appseo-ryf' ),
					array( 'status' => 404 )
				);
			}
			$anterior = $this->obtener( $id );
		} else {
			$producto = new WC_Product_Simple();
			$anterior = null;
		}

		$estado = isset( $data['estado'] ) ? sanitize_key( $data['estado'] ) : ( $id ? $producto->get_status() : 'draft' );
		if ( ! in_array( $estado, array( 'draft', 'pending', 'private', 'publish' ), true ) ) {
			$estado = 'draft';
		}
		if ( 'publish' === $estado && ! AppSEO_RyF_Settings::get( 'allow_publish', 0 ) ) {
			return new WP_Error(
				'appseo_publish_disabled',
				__( 'La publicación directa está desactivada en este sitio.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		if ( isset( $data['nombre'] ) ) {
			$producto->set_name( sanitize_text_field( $data['nombre'] ) );
		}
		if ( isset( $data['slug'] ) ) {
			$producto->set_slug( sanitize_title( $data['slug'] ) );
		}
		if ( isset( $data['descripcion'] ) ) {
			$producto->set_description( wp_kses_post( $data['descripcion'] ) );
		}
		if ( isset( $data['descripcion_corta'] ) ) {
			$producto->set_short_description( wp_kses_post( $data['descripcion_corta'] ) );
		}
		if ( isset( $data['categorias'] ) && is_array( $data['categorias'] ) ) {
			$producto->set_category_ids( array_map( 'intval', $data['categorias'] ) );
		}
		if ( isset( $data['imagen'] ) ) {
			$producto->set_image_id( (int) $data['imagen'] );
		}
		if ( isset( $data['galeria_ids'] ) && is_array( $data['galeria_ids'] ) ) {
			$producto->set_gallery_image_ids( array_map( 'intval', $data['galeria_ids'] ) );
		}

		// Precios: solo si el sitio lo ha autorizado explícitamente. Se pasa por
		// wc_format_decimal para no guardar cadenas que WooCommerce interprete
		// de forma rara según la configuración de separadores.
		if ( $precios_activos ) {
			if ( isset( $data['precio_regular'] ) ) {
				$producto->set_regular_price( wc_format_decimal( $data['precio_regular'] ) );
			}
			if ( isset( $data['precio_oferta'] ) ) {
				$oferta = '' === $data['precio_oferta'] ? '' : wc_format_decimal( $data['precio_oferta'] );
				$producto->set_sale_price( $oferta );
			}
		}

		$producto->set_status( $estado );

		$guardado = $producto->save();

		if ( ! $guardado ) {
			return new WP_Error(
				'appseo_producto_no_guardado',
				__( 'WooCommerce no pudo guardar el producto.', 'appseo-ryf' ),
				array( 'status' => 500 )
			);
		}

		if ( isset( $data['etiquetas'] ) && is_array( $data['etiquetas'] ) ) {
			wp_set_object_terms( $guardado, array_map( 'sanitize_text_field', $data['etiquetas'] ), 'product_tag' );
		}

		$meta_escrito = array();
		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			$contenido    = new AppSEO_RyF_Content();
			$meta_escrito = $contenido->escribir_meta_publico( $guardado, $data['meta'] );
		}

		AppSEO_RyF_Log::anotar(
			$id ? 'producto_editar' : 'producto_crear',
			array(
				'tipo'    => 'product',
				'id'      => $guardado,
				'resumen' => sprintf(
					/* translators: 1: nombre, 2: estado, 3: aviso de precio. */
					__( '«%1$s» (%2$s)%3$s', 'appseo-ryf' ),
					$producto->get_name(),
					get_post_status( $guardado ),
					( isset( $data['precio_regular'] ) || isset( $data['precio_oferta'] ) ) ? __( ' · con cambio de precio', 'appseo-ryf' ) : ''
				),
			)
		);

		return array(
			'id'           => $guardado,
			'creado'       => ! $id,
			'url'          => get_permalink( $guardado ),
			'editar'       => admin_url( 'post.php?post=' . $guardado . '&action=edit' ),
			'estado'       => get_post_status( $guardado ),
			'meta_escrito' => $meta_escrito,
			'anterior'     => $anterior,
		);
	}
}
