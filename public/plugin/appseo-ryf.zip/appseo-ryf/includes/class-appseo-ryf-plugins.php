<?php
/**
 * Gestión de plugins: listar, instalar, activar y desactivar.
 *
 * Deliberadamente NO borra. La eliminación de plugins queda como tarea manual
 * del administrador del sitio, porque es la única de estas operaciones que
 * destruye datos y no tiene vuelta atrás.
 *
 * La instalación acepta únicamente slugs del repositorio oficial de
 * WordPress.org. No admite URLs ni ZIPs arbitrarios: eso convertiría este
 * endpoint en ejecución de código remoto con pasos extra.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Operaciones sobre plugins.
 */
class AppSEO_RyF_Plugins {

	/**
	 * Carga las dependencias de administración que WordPress no incluye en REST.
	 *
	 * @return void
	 */
	protected function cargar_dependencias() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	}

	/**
	 * Comprueba que la gestión de plugins está permitida en este sitio.
	 *
	 * @return true|WP_Error
	 */
	protected function permitido() {
		if ( ! AppSEO_RyF_Settings::get( 'allow_plugin_management', 0 ) ) {
			return new WP_Error(
				'appseo_plugins_desactivado',
				__( 'La gestión de plugins está desactivada en este sitio. Actívala en Ajustes → AppSEO RyF.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		if ( AppSEO_RyF_Settings::is_read_only() ) {
			return new WP_Error(
				'appseo_read_only',
				__( 'Este sitio está en modo solo lectura.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$usuario = AppSEO_RyF_Settings::acting_user_id();
		if ( ! $usuario || ! user_can( $usuario, 'activate_plugins' ) ) {
			return new WP_Error(
				'appseo_sin_permiso',
				__( 'El usuario configurado no puede gestionar plugins.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Ruta del propio conector, que nunca debe manipularse a sí mismo.
	 *
	 * @return string
	 */
	protected function yo_mismo() {
		return plugin_basename( APPSEO_RYF_FILE );
	}

	/**
	 * Inventario de plugins instalados.
	 *
	 * @return array
	 */
	public function listar() {
		$this->cargar_dependencias();

		$salida = array();
		foreach ( get_plugins() as $archivo => $datos ) {
			$slug = dirname( $archivo );

			$salida[] = array(
				'archivo'     => $archivo,
				'slug'        => ( '.' === $slug ) ? basename( $archivo, '.php' ) : $slug,
				'nombre'      => $datos['Name'],
				'version'     => $datos['Version'],
				'activo'      => is_plugin_active( $archivo ),
				'red'         => is_plugin_active_for_network( $archivo ),
				'protegido'   => ( $archivo === $this->yo_mismo() ),
				'actualiza_a' => $this->version_disponible( $archivo ),
			);
		}

		return array(
			'plugins'          => $salida,
			'gestion_activa'   => (bool) AppSEO_RyF_Settings::get( 'allow_plugin_management', 0 ),
			'permite_instalar' => function_exists( 'wp_is_file_mod_allowed' ) ? wp_is_file_mod_allowed( 'install_plugin' ) : true,
			'metodo_archivos'  => get_filesystem_method(),
		);
	}

	/**
	 * Versión disponible según el transitorio de actualizaciones de WordPress.
	 *
	 * @param string $archivo Ruta relativa del plugin.
	 * @return string
	 */
	protected function version_disponible( $archivo ) {
		$updates = get_site_transient( 'update_plugins' );
		if ( isset( $updates->response[ $archivo ]->new_version ) ) {
			return $updates->response[ $archivo ]->new_version;
		}
		return '';
	}

	/**
	 * Instala un plugin desde el repositorio oficial.
	 *
	 * @param string $slug Slug en WordPress.org.
	 * @return array|WP_Error
	 */
	public function instalar( $slug ) {
		$puede = $this->permitido();
		if ( is_wp_error( $puede ) ) {
			return $puede;
		}

		$slug = sanitize_key( $slug );
		if ( '' === $slug || ! preg_match( '/^[a-z0-9-]{1,64}$/', $slug ) ) {
			return new WP_Error(
				'appseo_slug_invalido',
				__( 'El slug del plugin no tiene un formato válido.', 'appseo-ryf' ),
				array( 'status' => 400 )
			);
		}

		$lista_blanca = AppSEO_RyF_Settings::get( 'plugin_allowlist', array() );
		if ( is_array( $lista_blanca ) && ! empty( $lista_blanca ) && ! in_array( $slug, $lista_blanca, true ) ) {
			return new WP_Error(
				'appseo_slug_no_permitido',
				__( 'Ese plugin no está en la lista de permitidos de este sitio.', 'appseo-ryf' ),
				array( 'status' => 403 )
			);
		}

		$this->cargar_dependencias();

		if ( function_exists( 'wp_is_file_mod_allowed' ) && ! wp_is_file_mod_allowed( 'install_plugin' ) ) {
			return new WP_Error(
				'appseo_file_mods_bloqueado',
				__( 'Este WordPress tiene desactivada la modificación de archivos (DISALLOW_FILE_MODS).', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}

		// Si ya está instalado, no se reinstala: se informa y punto.
		$existente = $this->buscar_por_slug( $slug );
		if ( $existente ) {
			return array(
				'slug'      => $slug,
				'accion'    => 'ya_instalado',
				'archivo'   => $existente,
				'activo'    => is_plugin_active( $existente ),
			);
		}

		$api = plugins_api(
			'plugin_information',
			array(
				'slug'   => $slug,
				'fields' => array( 'sections' => false ),
			)
		);

		if ( is_wp_error( $api ) ) {
			return new WP_Error(
				'appseo_repo_error',
				sprintf(
					/* translators: %s: mensaje del repositorio. */
					__( 'WordPress.org no devolvió ese plugin: %s', 'appseo-ryf' ),
					$api->get_error_message()
				),
				array( 'status' => 404 )
			);
		}

		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$resultado = $upgrader->install( $api->download_link );

		if ( is_wp_error( $resultado ) ) {
			return new WP_Error( 'appseo_instalacion_fallida', $resultado->get_error_message(), array( 'status' => 500 ) );
		}
		if ( false === $resultado ) {
			$errores = $skin->get_error_messages();
			return new WP_Error(
				'appseo_instalacion_fallida',
				! empty( $errores ) ? implode( ' · ', $errores ) : __( 'La instalación no se completó.', 'appseo-ryf' ),
				array( 'status' => 500 )
			);
		}

		wp_clean_plugins_cache();
		$archivo = $this->buscar_por_slug( $slug );

		AppSEO_RyF_Log::anotar(
			'plugin_instalar',
			array(
				'tipo'    => 'plugin',
				'resumen' => $slug . ( isset( $api->version ) ? ' v' . $api->version : '' ),
			)
		);

		return array(
			'slug'    => $slug,
			'accion'  => 'instalado',
			'archivo' => $archivo,
			'version' => isset( $api->version ) ? $api->version : '',
			'activo'  => $archivo ? is_plugin_active( $archivo ) : false,
			'avisos'  => $skin->get_upgrade_messages(),
		);
	}

	/**
	 * Activa un plugin ya instalado.
	 *
	 * @param string $archivo Ruta relativa, por ejemplo `wordpress-seo/wp-seo.php`.
	 * @return array|WP_Error
	 */
	public function activar( $archivo ) {
		$puede = $this->permitido();
		if ( is_wp_error( $puede ) ) {
			return $puede;
		}

		$this->cargar_dependencias();
		$archivo = plugin_basename( sanitize_text_field( $archivo ) );

		$valido = validate_plugin( $archivo );
		if ( is_wp_error( $valido ) ) {
			return new WP_Error( 'appseo_plugin_invalido', $valido->get_error_message(), array( 'status' => 404 ) );
		}

		if ( is_plugin_active( $archivo ) ) {
			return array( 'archivo' => $archivo, 'accion' => 'ya_activo' );
		}

		$resultado = activate_plugin( $archivo );

		if ( is_wp_error( $resultado ) ) {
			return new WP_Error( 'appseo_activacion_fallida', $resultado->get_error_message(), array( 'status' => 500 ) );
		}

		AppSEO_RyF_Log::anotar( 'plugin_activar', array( 'tipo' => 'plugin', 'resumen' => $archivo ) );

		return array(
			'archivo' => $archivo,
			'accion'  => 'activado',
			'activo'  => is_plugin_active( $archivo ),
		);
	}

	/**
	 * Desactiva un plugin.
	 *
	 * @param string $archivo Ruta relativa.
	 * @return array|WP_Error
	 */
	public function desactivar( $archivo ) {
		$puede = $this->permitido();
		if ( is_wp_error( $puede ) ) {
			return $puede;
		}

		$this->cargar_dependencias();
		$archivo = plugin_basename( sanitize_text_field( $archivo ) );

		// Nunca desactivarse a sí mismo: cortaría la conexión y dejaría el
		// sitio inalcanzable desde el panel.
		if ( $archivo === $this->yo_mismo() ) {
			return new WP_Error(
				'appseo_autoproteccion',
				__( 'El conector no puede desactivarse a sí mismo. Hazlo desde el escritorio de WordPress.', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}

		$protegidos = apply_filters( 'appseo_ryf_plugins_protegidos', array() );
		if ( in_array( $archivo, $protegidos, true ) ) {
			return new WP_Error(
				'appseo_plugin_protegido',
				__( 'Ese plugin está protegido en este sitio.', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}

		$valido = validate_plugin( $archivo );
		if ( is_wp_error( $valido ) ) {
			return new WP_Error( 'appseo_plugin_invalido', $valido->get_error_message(), array( 'status' => 404 ) );
		}

		if ( ! is_plugin_active( $archivo ) ) {
			return array( 'archivo' => $archivo, 'accion' => 'ya_inactivo' );
		}

		deactivate_plugins( array( $archivo ) );

		AppSEO_RyF_Log::anotar( 'plugin_desactivar', array( 'tipo' => 'plugin', 'resumen' => $archivo ) );

		return array(
			'archivo' => $archivo,
			'accion'  => 'desactivado',
			'activo'  => is_plugin_active( $archivo ),
		);
	}

	/**
	 * Localiza el archivo principal de un plugin a partir de su slug.
	 *
	 * @param string $slug Slug.
	 * @return string Ruta relativa, o cadena vacía si no está instalado.
	 */
	protected function buscar_por_slug( $slug ) {
		foreach ( array_keys( get_plugins() ) as $archivo ) {
			if ( dirname( $archivo ) === $slug ) {
				return $archivo;
			}
		}
		return '';
	}
}
