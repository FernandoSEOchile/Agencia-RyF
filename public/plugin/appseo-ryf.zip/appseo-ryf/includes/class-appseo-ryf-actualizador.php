<?php
/**
 * Actualizaciones del propio conector.
 *
 * Usa el mecanismo nativo de WordPress para plugins alojados fuera del
 * repositorio oficial: la cabecera `Update URI` del archivo principal declara
 * quién manda las actualizaciones, y WordPress dispara el filtro
 * `update_plugins_<host>` para preguntarle.
 *
 * Se hace así, y no dejando que el panel empuje un ZIP, por una razón concreta:
 * el conector se niega por diseño a instalar archivos externos y a tocarse a sí
 * mismo, para que un panel comprometido no pueda inyectar código en la cartera
 * entera. Aquí el sitio consulta y decide; la instalación la hace WordPress con
 * sus propias comprobaciones.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Consulta al panel si hay una versión nueva del conector.
 */
class AppSEO_RyF_Actualizador {

	/** Dominio que sirve las actualizaciones. Debe coincidir con `Update URI`. */
	const HOST = 'panel.agenciaryf.com';

	/** Cuánto se guarda la respuesta antes de volver a preguntar. */
	const CACHE = 6 * HOUR_IN_SECONDS;

	/**
	 * Engancha el filtro que WordPress dispara para este host.
	 */
	public function register() {
		add_filter( 'update_plugins_' . self::HOST, array( $this, 'consultar' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( $this, 'decidir_automatica' ), 10, 2 );
	}

	/**
	 * Responde a WordPress con los datos de la versión disponible.
	 *
	 * @param array|false $actualizacion Lo que haya decidido otro filtro.
	 * @param array       $datos         Cabeceras del plugin.
	 * @param string      $archivo       Ruta relativa del plugin.
	 * @return array|false
	 */
	public function consultar( $actualizacion, $datos, $archivo ) {
		if ( plugin_basename( APPSEO_RYF_FILE ) !== $archivo ) {
			return $actualizacion;
		}

		$remoto = $this->version_publicada();

		if ( ! $remoto || empty( $remoto['version'] ) || empty( $remoto['paquete'] ) ) {
			return $actualizacion;
		}

		// Solo se ofrece si de verdad es más nueva: comparar mal aquí provoca
		// reinstalaciones en bucle en todos los clientes a la vez.
		if ( version_compare( $remoto['version'], APPSEO_RYF_VERSION, '<=' ) ) {
			return $actualizacion;
		}

		return array(
			'id'           => self::HOST . '/appseo-ryf',
			'slug'         => 'appseo-ryf',
			'plugin'       => $archivo,
			'version'      => $remoto['version'],
			'url'          => 'https://' . self::HOST,
			'package'      => $remoto['paquete'],
			'tested'       => isset( $remoto['probado'] ) ? $remoto['probado'] : '',
			'requires_php' => isset( $remoto['php'] ) ? $remoto['php'] : '',
		);
	}

	/**
	 * Activa la actualización automática si el sitio lo tiene permitido.
	 *
	 * @param bool|null $automatica Decisión previa.
	 * @param object    $item       Elemento a actualizar.
	 * @return bool|null
	 */
	public function decidir_automatica( $automatica, $item ) {
		if ( empty( $item->plugin ) || plugin_basename( APPSEO_RYF_FILE ) !== $item->plugin ) {
			return $automatica;
		}

		return (bool) AppSEO_RyF_Settings::get( 'auto_actualizar', 0 );
	}

	/**
	 * Pide al panel la última versión publicada.
	 *
	 * La respuesta se guarda en caché —incluido el fallo— para que un panel
	 * caído no añada una petición HTTP lenta a cada carga del escritorio.
	 *
	 * @return array|false
	 */
	protected function version_publicada() {
		$clave    = 'appseo_ryf_version_remota';
		$guardado = get_transient( $clave );

		if ( false !== $guardado ) {
			return is_array( $guardado ) ? $guardado : false;
		}

		$r = wp_remote_get(
			'https://' . self::HOST . '/api/plugin/version',
			array(
				'timeout' => 8,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		$datos = false;

		if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
			$json = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( is_array( $json ) && ! empty( $json['version'] ) ) {
				$datos = $json;
			}
		}

		set_transient( $clave, $datos ? $datos : 'no', self::CACHE );

		return $datos;
	}

	/**
	 * Olvida la versión cacheada, para comprobar en el momento.
	 */
	public static function olvidar_cache() {
		delete_transient( 'appseo_ryf_version_remota' );
	}
}
