<?php
/**
 * Actualizaciones del propio conector.
 *
 * Usa el mecanismo nativo de WordPress para plugins alojados fuera del
 * repositorio oficial: la cabecera `Update URI` del archivo principal declara
 * quién manda las actualizaciones, y WordPress dispara el filtro
 * `update_plugins_<host>` para preguntarle.
 *
 * Se hace así, y no dejando que el panel empuje un ZIP, por una razón concreta:
 * el conector se niega por diseño a instalar archivos externos y a tocarse a sí
 * mismo, para que un panel comprometido no pueda inyectar código en la cartera
 * entera. Aquí el sitio consulta y decide; la instalación la hace WordPress con
 * sus propias comprobaciones.
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

/**
 * Consulta al panel si hay una versión nueva del conector.
 */
class AppSEO_RyF_Actualizador {

	/** Dominio que sirve las actualizaciones. Debe coincidir con `Update URI`. */
	const HOST = 'panel.agenciaryf.com';

	/** Cuánto se guarda la respuesta antes de volver a preguntar. */
	const CACHE = 6 * HOUR_IN_SECONDS;

	/**
	 * Engancha el filtro que WordPress dispara para este host.
	 */
	public function register() {
		add_filter( 'update_plugins_' . self::HOST, array( $this, 'consultar' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( $this, 'decidir_automatica' ), 10, 2 );
	}

	/**
	 * Responde a WordPress con los datos de la versión disponible.
	 *
	 * @param array|false $actualizacion Lo que haya decidido otro filtro.
	 * @param array       $datos         Cabeceras del plugin.
	 * @param string      $archivo       Ruta relativa del plugin.
	 * @return array|false
	 */
	public function consultar( $actualizacion, $datos, $archivo ) {
		if ( plugin_basename( APPSEO_RYF_FILE ) !== $archivo ) {
			return $actualizacion;
		}

		$remoto = $this->version_publicada();

		if ( ! $remoto || empty( $remoto['version'] ) || empty( $remoto['paquete'] ) ) {
			return $actualizacion;
		}

		// Solo se ofrece si de verdad es más nueva: comparar mal aquí provoca
		// reinstalaciones en bucle en todos los clientes a la vez.
		if ( version_compare( $remoto['version'], APPSEO_RYF_VERSION, '<=' ) ) {
			return $actualizacion;
		}

		return array(
			'id'           => self::HOST . '/appseo-ryf',
			'slug'         => 'appseo-ryf',
			'plugin'       => $archivo,
			'version'      => $remoto['version'],
			'url'          => 'https://' . self::HOST,
			'package'      => $remoto['paquete'],
			'tested'       => isset( $remoto['probado'] ) ? $remoto['probado'] : '',
			'requires_php' => isset( $remoto['php'] ) ? $remoto['php'] : '',
		);
	}

	/**
	 * Activa la actualización automática si el sitio lo tiene permitido.
	 *
	 * @param bool|null $automatica Decisión previa.
	 * @param object    $item       Elemento a actualizar.
	 * @return bool|null
	 */
	public function decidir_automatica( $automatica, $item ) {
		if ( empty( $item->plugin ) || plugin_basename( APPSEO_RYF_FILE ) !== $item->plugin ) {
			return $automatica;
		}

		return (bool) AppSEO_RyF_Settings::get( 'auto_actualizar', 0 );
	}

	/**
	 * Pide al panel la última versión publicada.
	 *
	 * La respuesta se guarda en caché —incluido el fallo— para que un panel
	 * caído no añada una petición HTTP lenta a cada carga del escritorio.
	 *
	 * @return array|false
	 */
	protected function version_publicada() {
		$clave    = 'appseo_ryf_version_remota';
		$guardado = get_transient( $clave );

		if ( false !== $guardado ) {
			return is_array( $guardado ) ? $guardado : false;
		}

		$r = wp_remote_get(
			'https://' . self::HOST . '/api/plugin/version',
			array(
				'timeout' => 8,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		$datos = false;

		if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
			$json = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( is_array( $json ) && ! empty( $json['version'] ) ) {
				$datos = $json;
			}
		}

		set_transient( $clave, $datos ? $datos : 'no', self::CACHE );

		return $datos;
	}

	/**
	 * Olvida la versión cacheada, para comprobar en el momento.
	 */
	public static function olvidar_cache() {
		delete_transient( 'appseo_ryf_version_remota' );
	}

	/**
	 * Comprueba ahora mismo y, si el sitio lo permite, instala la nueva versión.
	 *
	 * El borrado de la caché ocurre siempre, incluso cuando no se puede
	 * instalar: no toca nada y hace que la actualización aparezca en el
	 * escritorio en el momento en vez de hasta seis horas después. Así el botón
	 * del panel sirve también en los sitios que prefieren decidir a mano.
	 *
	 * La instalación se autoriza con `allow_plugin_management`, que es
	 * exactamente el interruptor que significa «el panel puede tocar plugins
	 * aquí». No se mira `read_only`: eso protege el contenido del cliente, y
	 * usarlo también aquí dejaría en la versión más vieja justo a los sitios
	 * que menos se tocan.
	 *
	 * @return array|WP_Error
	 */
	public static function actualizar_ahora() {
		self::olvidar_cache();

		$actualizador = new self();
		$remoto       = $actualizador->version_publicada();

		if ( ! $remoto || empty( $remoto['version'] ) ) {
			return new WP_Error(
				'appseo_sin_version_remota',
				__( 'El panel no respondió con ninguna versión publicada.', 'appseo-ryf' ),
				array( 'status' => 502 )
			);
		}

		$estado = array(
			'instalada'  => APPSEO_RYF_VERSION,
			'disponible' => $remoto['version'],
		);

		if ( version_compare( $remoto['version'], APPSEO_RYF_VERSION, '<=' ) ) {
			return array_merge( $estado, array( 'actualizado' => false, 'motivo' => 'al_dia' ) );
		}

		if ( ! AppSEO_RyF_Settings::get( 'allow_plugin_management', 0 ) ) {
			return array_merge(
				$estado,
				array(
					'actualizado' => false,
					'motivo'      => 'sin_permiso',
					'aviso'       => __( 'Hay una versión nueva, pero este sitio no deja que el panel instale plugins. Actualízalo desde Plugins en el escritorio, donde ya aparece, o activa la gestión de plugins en Ajustes → AppSEO RyF.', 'appseo-ryf' ),
				)
			);
		}

		if ( empty( $remoto['paquete'] ) ) {
			return new WP_Error(
				'appseo_sin_paquete',
				__( 'La versión publicada no indica de dónde descargarse.', 'appseo-ryf' ),
				array( 'status' => 502 )
			);
		}

		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		if ( function_exists( 'wp_is_file_mod_allowed' ) && ! wp_is_file_mod_allowed( 'update_plugins' ) ) {
			return new WP_Error(
				'appseo_file_mods_bloqueado',
				__( 'Este WordPress tiene desactivada la modificación de archivos (DISALLOW_FILE_MODS).', 'appseo-ryf' ),
				array( 'status' => 409 )
			);
		}

		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );

		// `install` con sobrescritura y no `upgrade`: upgrade lee el transitorio
		// de actualizaciones de WordPress, que puede no haberse refrescado
		// todavía, y entonces no haría nada y diría que todo fue bien.
		$hecho = $upgrader->install( $remoto['paquete'], array( 'overwrite_package' => true ) );

		if ( is_wp_error( $hecho ) ) {
			return new WP_Error( 'appseo_actualizacion_fallida', $hecho->get_error_message(), array( 'status' => 500 ) );
		}

		if ( false === $hecho ) {
			$errores = $skin->get_error_messages();
			return new WP_Error(
				'appseo_actualizacion_fallida',
				! empty( $errores ) ? implode( ' · ', $errores ) : __( 'La actualización no se completó.', 'appseo-ryf' ),
				array( 'status' => 500 )
			);
		}

		wp_clean_plugins_cache();

		AppSEO_RyF_Log::anotar(
			'conector_actualizar',
			array(
				'tipo'    => 'plugin',
				'resumen' => sprintf(
					/* translators: 1: versión anterior, 2: versión nueva. */
					__( 'Conector de v%1$s a v%2$s', 'appseo-ryf' ),
					APPSEO_RYF_VERSION,
					$remoto['version']
				),
			)
		);

		return array_merge(
			$estado,
			array(
				'actualizado' => true,
				'motivo'      => 'instalada',
				'avisos'      => $skin->get_upgrade_messages(),
			)
		);
	}
}
