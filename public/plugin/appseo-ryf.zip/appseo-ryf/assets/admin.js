/**
 * Comportamiento de la pantalla de AppSEO RyF.
 *
 * Dos cosas: copiar la cadena de conexión, y atenuar los permisos que dependen
 * del interruptor principal para que se vea de un vistazo que no tienen efecto.
 */
(function () {
	"use strict";

	document.addEventListener("DOMContentLoaded", function () {
		var raiz = document.querySelector(".appseo-wrap");
		if (!raiz) {
			return;
		}

		/* ---- copiar la cadena de conexión ---- */
		var boton = raiz.querySelector(".appseo-copiar");
		var campo = raiz.querySelector("#appseo-cadena");

		if (boton && campo) {
			boton.addEventListener("click", function () {
				var textoOriginal = boton.textContent;

				var exito = function () {
					boton.textContent = boton.dataset.copiado || "Copiado";
					boton.classList.add("esta-copiado");
					setTimeout(function () {
						boton.textContent = textoOriginal;
						boton.classList.remove("esta-copiado");
					}, 2000);
				};

				// El portapapeles moderno solo existe en contextos seguros; en
				// un WordPress servido por HTTP hay que recurrir a la selección.
				if (navigator.clipboard && window.isSecureContext) {
					navigator.clipboard.writeText(campo.value).then(exito, function () {
						campo.select();
					});
				} else {
					campo.select();
					try {
						document.execCommand("copy");
						exito();
					} catch (e) {
						/* el usuario copia a mano */
					}
				}
			});
		}

		/* ---- dependencias entre permisos ---- */
		var principal = raiz.querySelector('input[name="allow_writes"]');
		var dependientes = raiz.querySelectorAll("[data-depende-de-escritura]");

		function refrescar() {
			var activo = principal ? principal.checked : true;
			Array.prototype.forEach.call(dependientes, function (fila) {
				// Solo se atenúan. Desactivarlos con `disabled` impediría que
				// se enviaran al guardar, y sus valores se perderían sin que
				// nadie los hubiera tocado.
				fila.classList.toggle("esta-inactivo", !activo);
			});
		}

		if (principal) {
			principal.addEventListener("change", refrescar);
			refrescar();
		}

		/* ---- confirmación al regenerar ---- */
		var regenerar = raiz.querySelector('[name="regenerar"]');
		if (regenerar) {
			regenerar.addEventListener("click", function (e) {
				if (!window.confirm(regenerar.dataset.confirmar || "¿Seguro?")) {
					e.preventDefault();
				}
			});
		}
	});
})();
