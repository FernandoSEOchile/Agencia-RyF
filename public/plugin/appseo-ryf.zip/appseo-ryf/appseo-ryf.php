<?php
/**
 * Plugin Name:       AppSEO RyF
 * Plugin URI:        https://agenciaryf.com/
 * Description:       Conecta este sitio con el panel AppSEO para auditorías de contenido y publicación asistida. No ejecuta código remoto ni escribe en el sistema de archivos. Desarrollado por Agencia RYF.
 * Version:           1.18.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Agencia RYF
 * Author URI:        https://agenciaryf.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       appseo-ryf
 * Update URI:        https://panel.agenciaryf.com/appseo-ryf
 *
 * @package AppSEO_RyF
 */

defined( 'ABSPATH' ) || exit;

define( 'APPSEO_RYF_VERSION', '1.18.0' );
define( 'APPSEO_RYF_FILE', __FILE__ );
define( 'APPSEO_RYF_DIR', plugin_dir_path( __FILE__ ) );
define( 'APPSEO_RYF_NAMESPACE', 'appseo/v1' );

/** Nombre de la opción donde vive toda la configuración del plugin. */
define( 'APPSEO_RYF_OPTION', 'appseo_ryf_settings' );

require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-settings.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-log.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-auth.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-audit.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-content.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-estilos.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-tema.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-plugins.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-woo.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-categorias.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-actualizador.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-rest.php';
require_once APPSEO_RYF_DIR . 'includes/class-appseo-ryf-admin.php';

/**
 * Genera las credenciales de emparejamiento la primera vez que se activa.
 *
 * No sobrescribe unas credenciales existentes: reactivar el plugin nunca debe
 * desconectar un sitio que ya estaba emparejado.
 */
function appseo_ryf_activate() {
	AppSEO_RyF_Log::instalar();
	AppSEO_RyF_Categorias::sembrar_css();

	$settings = AppSEO_RyF_Settings::all();

	if ( empty( $settings['key_id'] ) || empty( $settings['secret'] ) ) {
		AppSEO_RyF_Settings::update(
			array(
				'key_id'     => AppSEO_RyF_Auth::generate_key_id(),
				'secret'     => AppSEO_RyF_Auth::generate_secret(),
				'paired_at'  => 0,
				'read_only'  => 1,
				'acting_user'=> get_current_user_id(),
			)
		);
	}
}
register_activation_hook( __FILE__, 'appseo_ryf_activate' );

/**
 * Arranca el plugin.
 */
function appseo_ryf_boot() {
	load_plugin_textdomain( 'appseo-ryf', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	( new AppSEO_RyF_REST() )->register();
	( new AppSEO_RyF_Categorias() )->register();
	( new AppSEO_RyF_Actualizador() )->register();

	if ( is_admin() ) {
		( new AppSEO_RyF_Admin() )->register();
	}
}
add_action( 'plugins_loaded', 'appseo_ryf_boot' );

/**
 * Enlace directo a los ajustes desde la lista de plugins.
 *
 * @param array $links Enlaces existentes.
 * @return array
 */
function appseo_ryf_action_links( $links ) {
	$url = admin_url( 'admin.php?page=appseo-ryf' );
	array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Ajustes', 'appseo-ryf' ) . '</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'appseo_ryf_action_links' );
