# AppSEO RyF

Desarrollado por **[Agencia RYF](https://agenciaryf.com/)**.

Plugin conector que enlaza un WordPress de cliente con el panel AppSEO.

**Diseñado con un límite explícito: no ejecuta código.** No hay `eval`, ni ejecución de PHP remoto, ni escritura en el sistema de archivos, ni instalación de plugins. Si este plugin se viera comprometido, el atacante podría alterar contenido — no tomar el servidor.

---

## Instalación en el sitio del cliente

1. Sube la carpeta `appseo-ryf/` a `wp-content/plugins/` (o instala el ZIP).
2. Actívalo.
3. Ve a **Ajustes → AppSEO RyF**.
4. Copia la **cadena de conexión** y pégala en el panel.

El plugin arranca en **modo solo lectura**. Hasta que lo desactives a mano, el panel puede auditar pero no cambiar nada.

### Usuario dedicado

En **Autor de los cambios**, crea y selecciona un usuario propio (por ejemplo `appseo`, rol Editor). Así el historial de revisiones del cliente distingue lo que hizo el panel de lo que hizo su equipo, y revocar el acceso es tan simple como desactivar ese usuario.

---

## Protocolo

Base: `https://ELSITIO/wp-json/appseo/v1`

### Autenticación

Cada petición va firmada con HMAC-SHA256. **El secreto nunca viaja**, así que no queda en logs de servidor ni en proxies intermedios.

Cabeceras obligatorias:

| Cabecera | Contenido |
|---|---|
| `X-AppSEO-Key` | identificador de clave (público) |
| `X-AppSEO-Timestamp` | segundos Unix |
| `X-AppSEO-Nonce` | 16–128 caracteres `[A-Za-z0-9_-]`, único por petición |
| `X-AppSEO-Signature` | HMAC-SHA256 en hexadecimal |

Cadena canónica firmada:

```
MÉTODO \n RUTA \n TIMESTAMP \n NONCE \n sha256hex(cuerpo)
```

`RUTA` es **solo la ruta, sin la cadena de consulta**: para `GET /audit?limit=500` se firma `/appseo/v1/audit`. Es lo que devuelve `$request->get_route()` en WordPress.

> Los parámetros de consulta quedan fuera de la firma a propósito. Incluirlos obligaría a que PHP y JavaScript los ordenaran y codificaran de forma idéntica, y esa clase de discrepancia produce fallos silenciosos difíciles de depurar. El **cuerpo sí va firmado**, así que toda escritura queda cubierta; los parámetros solo existen en endpoints de lectura, donde como mucho amplían o reducen una consulta que el llamante ya está autorizado a hacer.

El cuerpo es la cadena cruda; para `GET` es cadena vacía (y su sha256 es el hash de la cadena vacía, no un hash vacío).

Protecciones: ventana de ±300 s contra desfase horario, y los nonces se recuerdan 900 s para rechazar reenvíos.

### Firmar desde el panel (Node)

```js
import { createHmac, createHash, randomBytes } from "node:crypto";

export async function llamar(conexion, metodo, ruta, cuerpo = null) {
  const raw = cuerpo ? JSON.stringify(cuerpo) : "";
  const ts = String(Math.floor(Date.now() / 1000));
  const nonce = randomBytes(16).toString("base64url");

  const canonical = [
    metodo.toUpperCase(),
    ruta.split("?")[0],   // sin cadena de consulta
    ts,
    nonce,
    createHash("sha256").update(raw).digest("hex"),
  ].join("\n");

  const firma = createHmac("sha256", conexion.secret).update(canonical).digest("hex");

  const res = await fetch(conexion.rest + ruta.replace("/appseo/v1", ""), {
    method: metodo,
    headers: {
      "Content-Type": "application/json",
      "X-AppSEO-Key": conexion.key_id,
      "X-AppSEO-Timestamp": ts,
      "X-AppSEO-Nonce": nonce,
      "X-AppSEO-Signature": firma,
    },
    ...(raw ? { body: raw } : {}),
  });

  return res.json();
}
```

La cadena de conexión se decodifica quitando el prefijo `appseo_` y aplicando base64url → JSON con `{ site, rest, key_id, secret }`.

---

## Endpoints

### `GET /health`

Estado del conector: versiones, si está en solo lectura, si permite publicar y cuándo se conectó el panel por última vez. Úsalo como comprobación de vida.

### `GET /audit`

El endpoint que justifica el plugin. Calcula la auditoría **en el servidor del cliente** y devuelve un resumen compacto en lugar de obligar al panel a descargar cientos de páginas.

Parámetros: `limit` (500 por defecto, máximo 2000), `modified_after` (fecha ISO, para sincronización incremental) e `include_links`.

Devuelve, por cada pieza: recuento de palabras (compatible con acentos y eñes, a diferencia de `str_word_count`), editor usado, imagen destacada, metadatos SEO de Yoast o Rank Math, y **marcadores de texto de relleno** sin publicar. Además, el grafo de enlaces internos —extraído también del JSON de Elementor—, los menús, las taxonomías y el inventario de plugins.

Si el sitio supera el límite, `truncated.was_capped` lo indica. Nunca se recorta en silencio.

### `GET /content/{id}`

Una pieza completa, con su `_elementor_data` y sus metadatos SEO.

### `POST /content`

Crea o actualiza. Envía `id` para actualizar, omítelo para crear.

```json
{
  "tipo": "post",
  "titulo": "…",
  "slug": "…",
  "contenido": "<!-- wp:paragraph -->…",
  "extracto": "…",
  "estado": "draft",
  "categorias": [6],
  "destacada": 2603,
  "meta": {
    "_yoast_wpseo_focuskw": "consultoria seo",
    "_yoast_wpseo_metadesc": "…"
  }
}
```

Devuelve el estado **anterior** de la pieza en `anterior`, para que el panel pueda deshacer el cambio.

Solo se aceptan metadatos cuya clave empiece por `_yoast_wpseo_`, `_elementor_` o `rank_math_`. El resto se rechaza y se informa en `meta_escrito.rechazadas`. No hay escritura de meta arbitrario a propósito: sería una puerta trasera disfrazada.

**Editar y publicar.** Enviar `id` actualiza en lugar de crear. Solo se tocan los campos presentes: si omites `estado`, la entrada conserva el suyo; si omites `contenido`, no se toca. Para publicar, `"estado": "publish"` — requiere que *Publicación directa* esté activada en los ajustes del sitio.

### `GET /plugins`

Inventario de plugins instalados: nombre, versión, slug, si está activo, si tiene actualización pendiente y si está protegido. Devuelve también `gestion_activa`, `permite_instalar` (respeta `DISALLOW_FILE_MODS`) y `metodo_archivos`.

Esta ruta es de lectura y funciona siempre, aunque la gestión de plugins esté desactivada.

### `POST /plugins`

```json
{ "accion": "instalar", "slug": "wordpress-seo" }
{ "accion": "activar", "archivo": "wordpress-seo/wp-seo.php" }
{ "accion": "desactivar", "archivo": "wordpress-seo/wp-seo.php" }
```

**No existe la acción de borrar.** Eliminar plugins queda como tarea manual del administrador: es la única de estas operaciones que destruye datos sin vuelta atrás.

Límites de `instalar`:

- **Solo por slug del repositorio oficial de WordPress.org.** No acepta URLs ni ZIPs. Sin este límite, el endpoint sería ejecución de código remoto con pasos intermedios.
- Interruptor propio, apagado por defecto y separado del de contenido.
- Lista blanca de slugs opcional por sitio.
- El conector **no puede desactivarse a sí mismo**: cortaría la conexión y dejaría el sitio inalcanzable desde el panel.

### `POST /media`

Sube un archivo en base64: `{ "nombre": "foto.jpg", "contenido": "<base64>", "alt": "…" }`.

**SVG está bloqueado por defecto.** Un SVG puede contener JavaScript y convertirse en un XSS en el sitio del cliente. Se habilita con el filtro `appseo_ryf_allowed_mimes` si alguien acepta ese riesgo conscientemente.

---

## Filtros disponibles

| Filtro | Para qué |
|---|---|
| `appseo_ryf_allowed_meta_prefixes` | ampliar la lista blanca de metadatos |
| `appseo_ryf_allowed_mimes` | cambiar los tipos de archivo aceptados |
| `appseo_ryf_placeholder_needles` | añadir patrones de texto de relleno |

---

## Códigos de error

| Código | HTTP | Significado |
|---|---|---|
| `appseo_missing_headers` | 401 | faltan cabeceras de firma |
| `appseo_bad_signature` | 401 | la firma no coincide |
| `appseo_stale_request` | 401 | desfase horario mayor de 300 s |
| `appseo_replay` | 409 | nonce ya usado |
| `appseo_read_only` | 403 | el sitio no acepta escrituras |
| `appseo_publish_disabled` | 403 | publicación directa desactivada |
| `appseo_no_acting_user` | 409 | sin usuario válido para atribuir cambios |
| `appseo_mime_no_permitido` | 415 | tipo de archivo bloqueado |

---

## Lo que este plugin no hace, y no hará

Ejecutar PHP, correr WP-CLI, leer o escribir archivos del servidor, instalar o activar plugins, tocar usuarios, y acceder a pedidos o datos de clientes de WooCommerce.

No es una limitación pendiente de resolver: es la decisión de diseño que hace responsable instalarlo en sitios de terceros.
